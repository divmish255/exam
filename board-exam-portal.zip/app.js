// CBSE MasterRank AI Application Engine (Exclusively for CBSE Class 10 & 12)

const AppState = {
  user: {
    identifier: localStorage.getItem('cbse_user_identifier') || 'student@cbse.nic.in',
    type: localStorage.getItem('cbse_user_type') || 'email', // 'email' or 'phone'
    goalScore: parseInt(localStorage.getItem('cbse_user_goal') || '95', 10),
    isLoggedIn: !!localStorage.getItem('cbse_user_identifier'),
    generatedOtp: null
  },
  currentTheme: localStorage.getItem('cbse_theme') || 'default',
  currentClass: localStorage.getItem('cbse_user_class') || 'class12',
  currentStream: localStorage.getItem('cbse_user_stream') || 'science_pcm',
  selectedAnswers: {},
  syllabusProgress: JSON.parse(localStorage.getItem('cbse_syllabus_progress') || '{}'),
  customPyqs: JSON.parse(localStorage.getItem('cbse_custom_pyqs') || '[]'),
  timer: {
    intervalId: null,
    remainingSeconds: 50 * 60,
    isRunning: false,
    mode: 'study'
  },
  breathing: {
    isActive: false
  },
  lastMockResult: {
    score: 5,
    total: 5,
    percentile: 97.2,
    air: 3842
  }
};

// --- Web Audio API Alarm Synthesizer ---
class AlarmSoundSystem {
  constructor() {
    this.audioCtx = null;
  }

  init() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  playAlarmBuzzer() {
    this.init();
    if (!this.audioCtx) return;
    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    for (let i = 0; i < 4; i++) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(880, now + i * 0.35);
      osc.frequency.exponentialRampToValueAtTime(1760, now + i * 0.35 + 0.15);
      gain.gain.setValueAtTime(0.3, now + i * 0.35);
      gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.35 + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + i * 0.35);
      osc.stop(now + i * 0.35 + 0.25);
    }
  }

  playZenChime() {
    this.init();
    if (!this.audioCtx) return;
    const ctx = this.audioCtx;
    const now = ctx.currentTime;
    [528, 660, 792].forEach(freq => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 2.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 2.5);
    });
  }
}

const alarmAudio = new AlarmSoundSystem();

// --- DOM References ---
const DOM = {
  classSelect: document.getElementById('classSelect'),
  streamSelect: document.getElementById('streamSelect'),
  themeSelect: document.getElementById('themeSelect'),
  authBtn: document.getElementById('authBtn'),
  userEmailBadge: document.getElementById('userEmailBadge'),
  openPanicBtn: document.getElementById('openPanicBtn'),
  tabBtns: document.querySelectorAll('.tab-btn'),
  tabPanes: document.querySelectorAll('.tab-pane'),

  // Auth Modal (Email or Phone + OTP)
  authModal: document.getElementById('authModal'),
  closeAuthModal: document.getElementById('closeAuthModal'),
  authForm: document.getElementById('authForm'),
  userIdentifierInput: document.getElementById('userIdentifierInput'),
  userGoalInput: document.getElementById('userGoalInput'),
  sendOtpBtn: document.getElementById('sendOtpBtn'),
  otpForm: document.getElementById('otpForm'),
  otpInput: document.getElementById('otpInput'),
  otpSentTo: document.getElementById('otpSentTo'),
  verifyOtpBtn: document.getElementById('verifyOtpBtn'),
  otpBackBtn: document.getElementById('otpBackBtn'),
  loggedInBox: document.getElementById('loggedInBox'),
  loggedInEmail: document.getElementById('loggedInEmail'),
  logoutBtn: document.getElementById('logoutBtn'),
  authMessage: document.getElementById('authMessage'),

  // Admin PYQ Upload Modal (2016-2026)
  openAdminPyqModalBtn: document.getElementById('openAdminPyqModalBtn'),
  adminPyqModal: document.getElementById('adminPyqModal'),
  closeAdminPyqModal: document.getElementById('closeAdminPyqModal'),
  adminPyqForm: document.getElementById('adminPyqForm'),
  adminPyqYear: document.getElementById('adminPyqYear'),
  adminPyqClass: document.getElementById('adminPyqClass'),
  adminPyqSubject: document.getElementById('adminPyqSubject'),
  adminPyqTitle: document.getElementById('adminPyqTitle'),
  adminPyqHighlights: document.getElementById('adminPyqHighlights'),

  // 100 Question Papers
  qpSubjectFilter: document.getElementById('qpSubjectFilter'),
  qpTypeFilter: document.getElementById('qpTypeFilter'),
  questionPapersGrid: document.getElementById('questionPapersGrid'),

  // Dashboard
  dashSyllabusPct: document.getElementById('dashSyllabusPct'),
  dashSyllabusBar: document.getElementById('dashSyllabusBar'),
  dashSyllabusRemaining: document.getElementById('dashSyllabusRemaining'),
  dashMockScore: document.getElementById('dashMockScore'),
  dashEstimatedAir: document.getElementById('dashEstimatedAir'),
  dashStudyHrs: document.getElementById('dashStudyHrs'),
  weeklyTableBody: document.getElementById('weeklyTableBody'),
  syncReportBtn: document.getElementById('syncReportBtn'),

  // Planner
  plannerScoreBracket: document.getElementById('plannerScoreBracket'),
  plannerDaysLeft: document.getElementById('plannerDaysLeft'),
  calculatePlanBtn: document.getElementById('calculatePlanBtn'),
  plannerOutputCard: document.getElementById('plannerOutputCard'),

  // Syllabus
  syllabusSubjectFilter: document.getElementById('syllabusSubjectFilter'),
  syllabusListContainer: document.getElementById('syllabusListContainer'),
  syllCompletedCount: document.getElementById('syllCompletedCount'),
  syllInProgressCount: document.getElementById('syllInProgressCount'),
  syllPendingCount: document.getElementById('syllPendingCount'),

  // Mock Test
  mockSubjectFilter: document.getElementById('mockSubjectFilter'),
  mockTypeFilter: document.getElementById('mockTypeFilter'),
  quizContainer: document.getElementById('quizContainer'),
  submitQuizBtn: document.getElementById('submitQuizBtn'),
  resetQuizBtn: document.getElementById('resetQuizBtn'),
  quizResultArea: document.getElementById('quizResultArea'),
  resultAirRank: document.getElementById('resultAirRank'),
  resultPercentile: document.getElementById('resultPercentile'),
  resultRawScore: document.getElementById('resultRawScore'),
  resultFeedback: document.getElementById('resultFeedback'),

  // Subjective
  subjectiveQuestionSelect: document.getElementById('subjectiveQuestionSelect'),
  subqSubjectBadge: document.getElementById('subqSubjectBadge'),
  subqMarksBadge: document.getElementById('subqMarksBadge'),
  subqText: document.getElementById('subqText'),
  studentSubjectiveInput: document.getElementById('studentSubjectiveInput'),
  evaluateAnswerBtn: document.getElementById('evaluateAnswerBtn'),
  showModelAnswerBtn: document.getElementById('showModelAnswerBtn'),
  evalResultContainer: document.getElementById('evalResultContainer'),

  // PYQs
  pyqYearFilter: document.getElementById('pyqYearFilter'),
  pyqGrid: document.getElementById('pyqGrid'),

  // Leaderboard
  leaderboardTableBody: document.getElementById('leaderboardTableBody'),
  refreshLeaderboardBtn: document.getElementById('refreshLeaderboardBtn'),

  // Report Card Upload
  reportLoggedOut: document.getElementById('reportLoggedOut'),
  reportLoggedIn: document.getElementById('reportLoggedIn'),
  reportLoginBtn: document.getElementById('reportLoginBtn'),
  reportFileInput: document.getElementById('reportFileInput'),
  uploadReportBtn: document.getElementById('uploadReportBtn'),
  reportMsg: document.getElementById('reportMsg'),
  reportList: document.getElementById('reportList'),

  // Timer & Alarm
  timerDisplay: document.getElementById('timerDisplay'),
  startTimerBtn: document.getElementById('startTimerBtn'),
  breakTimerBtn: document.getElementById('breakTimerBtn'),
  stopTimerBtn: document.getElementById('stopTimerBtn'),
  testAlarmSoundBtn: document.getElementById('testAlarmSoundBtn'),
  timerStatusLabel: document.getElementById('timerStatusLabel'),
  examCountdownTicker: document.getElementById('examCountdownTicker'),

  // Motivation & Panic
  breathingBubble: document.getElementById('breathingBubble'),
  toggleBreathingBtn: document.getElementById('toggleBreathingBtn'),
  dailyQuoteText: document.getElementById('dailyQuoteText'),
  dailyQuoteAuthor: document.getElementById('dailyQuoteAuthor'),
  nextQuoteBtn: document.getElementById('nextQuoteBtn')
};

// --- Initialization ---
function initApp() {
  // Apply saved theme
  applyTheme(AppState.currentTheme);
  if (DOM.themeSelect) DOM.themeSelect.value = AppState.currentTheme;

  // Initialize custom PYQs if any
  if (AppState.customPyqs && AppState.customPyqs.length > 0) {
    PORTAL_DATA.pyqVault = [...AppState.customPyqs, ...PORTAL_DATA.pyqVault];
  }

  updateStreamOptions();
  DOM.classSelect.value = AppState.currentClass;
  DOM.streamSelect.value = AppState.currentStream;

  updateUserBadge();
  setupTabNavigation();
  setupEventListeners();

  // Load modules
  renderStudyPlanner();
  renderWeeklyDashboard();
  render100QuestionPapers();
  renderSyllabusList();
  renderQuizQuestions();
  populateSubjectiveQuestions();
  renderPyqVault();
  renderLeaderboard();
  startExamCountdown();
  showRandomQuote();
  checkSession();
}

// Light Dual-Color Theme Handler
function applyTheme(theme) {
  document.body.className = '';
  if (theme && theme !== 'default') {
    document.body.classList.add(theme);
  }
  AppState.currentTheme = theme;
  localStorage.setItem('cbse_theme', theme);
}

// Stream Options updater
function updateStreamOptions() {
  const cls = DOM.classSelect.value;
  const streams = PORTAL_DATA.streams[cls] || [];

  DOM.streamSelect.innerHTML = streams
    .map(s => `<option value="${s.id}">${s.name}</option>`)
    .join('');

  if (cls === 'class10') {
    AppState.currentStream = 'general';
  } else if (!streams.find(s => s.id === AppState.currentStream)) {
    AppState.currentStream = streams[0]?.id || 'science_pcm';
  }
  DOM.streamSelect.value = AppState.currentStream;
  updateSubjectFilters();
}

function updateSubjectFilters() {
  const cls = AppState.currentClass;
  const subjectsMap = PORTAL_DATA.syllabi[cls] || {};
  const subjects = Object.keys(subjectsMap);

  DOM.syllabusSubjectFilter.innerHTML = subjects
    .map(sub => `<option value="${sub}">${sub}</option>`)
    .join('');

  DOM.mockSubjectFilter.innerHTML = `<option value="all">All Stream Subjects</option>` +
    subjects.map(sub => `<option value="${sub}">${sub}</option>`).join('');

  if (DOM.qpSubjectFilter) {
    DOM.qpSubjectFilter.innerHTML = `<option value="all">All Subjects</option>` +
      subjects.map(sub => `<option value="${sub}">${sub}</option>`).join('');
  }
}

function updateUserBadge() {
  if (AppState.user.isLoggedIn) {
    DOM.userEmailBadge.textContent = `👤 ${AppState.user.identifier} (${AppState.user.goalScore}%)`;
    DOM.authBtn.classList.remove('btn-primary');
    DOM.authBtn.classList.add('btn-outline');
  } else {
    DOM.userEmailBadge.innerHTML = `👤 Login (Email / Phone)`;
    DOM.authBtn.classList.add('btn-primary');
  }
}

function setupTabNavigation() {
  DOM.tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      DOM.tabBtns.forEach(b => b.classList.remove('active'));
      DOM.tabPanes.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPane = document.getElementById(`tab-${targetTab}`);
      if (targetPane) targetPane.classList.add('active');
    });
  });
}

function switchTab(tabName) {
  const targetBtn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
  if (targetBtn) targetBtn.click();
}

// --- Event Listeners ---
function setupEventListeners() {
  // Theme Switcher
  if (DOM.themeSelect) {
    DOM.themeSelect.addEventListener('change', (e) => applyTheme(e.target.value));
  }

  // Class and Stream change
  DOM.classSelect.addEventListener('change', (e) => {
    AppState.currentClass = e.target.value;
    localStorage.setItem('cbse_user_class', AppState.currentClass);
    updateStreamOptions();
    render100QuestionPapers();
    renderSyllabusList();
    renderQuizQuestions();
    populateSubjectiveQuestions();
    renderPyqVault();
    renderStudyPlanner();
  });

  DOM.streamSelect.addEventListener('change', (e) => {
    AppState.currentStream = e.target.value;
    localStorage.setItem('cbse_user_stream', AppState.currentStream);
    render100QuestionPapers();
    renderSyllabusList();
    renderQuizQuestions();
    populateSubjectiveQuestions();
  });

  // Auth Modal
  DOM.authBtn.addEventListener('click', openAuthModal);
  DOM.closeAuthModal.addEventListener('click', () => { DOM.authModal.style.display = 'none'; });
  DOM.authForm.addEventListener('submit', handleSendOtp);
  DOM.otpForm.addEventListener('submit', handleVerifyOtp);
  DOM.otpBackBtn.addEventListener('click', () => showAuthView('identifier'));
  DOM.logoutBtn.addEventListener('click', handleLogout);

  // Admin PYQ Upload Modal
  if (DOM.openAdminPyqModalBtn) {
    DOM.openAdminPyqModalBtn.addEventListener('click', () => { DOM.adminPyqModal.style.display = 'flex'; });
  }
  if (DOM.closeAdminPyqModal) {
    DOM.closeAdminPyqModal.addEventListener('click', () => { DOM.adminPyqModal.style.display = 'none'; });
  }
  if (DOM.adminPyqForm) {
    DOM.adminPyqForm.addEventListener('submit', handleAdminPyqSubmit);
  }

  // 100 Question Papers filters
  if (DOM.qpSubjectFilter) DOM.qpSubjectFilter.addEventListener('change', render100QuestionPapers);
  if (DOM.qpTypeFilter) DOM.qpTypeFilter.addEventListener('change', render100QuestionPapers);

  // Report card upload
  DOM.reportLoginBtn.addEventListener('click', openAuthModal);
  DOM.uploadReportBtn.addEventListener('click', handleUploadReport);

  // Quick Panic Button
  DOM.openPanicBtn.addEventListener('click', () => {
    switchTab('motivation');
    startBreathingExercise();
    alarmAudio.playZenChime();
  });

  // Planner
  DOM.calculatePlanBtn.addEventListener('click', renderStudyPlanner);

  // Syllabus Subject filter
  DOM.syllabusSubjectFilter.addEventListener('change', renderSyllabusList);

  // Mock Test
  DOM.mockSubjectFilter.addEventListener('change', renderQuizQuestions);
  DOM.mockTypeFilter.addEventListener('change', renderQuizQuestions);
  DOM.submitQuizBtn.addEventListener('click', submitQuizAndCalculateAir);
  DOM.resetQuizBtn.addEventListener('click', () => {
    AppState.selectedAnswers = {};
    DOM.quizResultArea.style.display = 'none';
    renderQuizQuestions();
  });

  // Subjective Evaluator
  DOM.subjectiveQuestionSelect.addEventListener('change', updateActiveSubjectiveQuestion);
  DOM.evaluateAnswerBtn.addEventListener('click', evaluateSubjectiveAnswer);
  DOM.showModelAnswerBtn.addEventListener('click', toggleModelAnswer);

  // PYQ Filter
  DOM.pyqYearFilter.addEventListener('change', renderPyqVault);

  // Leaderboard
  DOM.refreshLeaderboardBtn.addEventListener('click', () => {
    renderLeaderboard();
    alert('🏆 CBSE All India Leaderboard Refreshed!');
  });

  // Study Alarm & Countdown
  DOM.startTimerBtn.addEventListener('click', startStudyTimer);
  DOM.breakTimerBtn.addEventListener('click', startBreakTimer);
  DOM.stopTimerBtn.addEventListener('click', stopTimer);
  DOM.testAlarmSoundBtn.addEventListener('click', () => { alarmAudio.playAlarmBuzzer(); });

  // Panic & Motivation
  DOM.toggleBreathingBtn.addEventListener('click', toggleBreathingExercise);
  DOM.nextQuoteBtn.addEventListener('click', showRandomQuote);

  // Sync dashboard
  DOM.syncReportBtn.addEventListener('click', () => {
    renderWeeklyDashboard();
    renderLeaderboard();
    alert('✅ CBSE board analytics and study logs refreshed!');
  });
}

// --- MODULE 1: 100 CBSE QUESTION PAPERS REPOSITORY ---
function render100QuestionPapers() {
  const cls = AppState.currentClass;
  const subFilter = DOM.qpSubjectFilter ? DOM.qpSubjectFilter.value : 'all';
  const typeFilter = DOM.qpTypeFilter ? DOM.qpTypeFilter.value : 'all';

  let papers = PORTAL_DATA.questionPaperSets.filter(p => p.class === cls);

  if (subFilter !== 'all') {
    papers = papers.filter(p => p.subject.toLowerCase() === subFilter.toLowerCase());
  }

  if (typeFilter !== 'all') {
    papers = papers.filter(p => p.type.toLowerCase().includes(typeFilter.toLowerCase()));
  }

  DOM.questionPapersGrid.innerHTML = papers.map(paper => `
    <div class="card" style="margin-bottom: 0;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
        <span class="badge badge-stream">${paper.subject}</span>
        <span class="badge badge-expected">${paper.type}</span>
      </div>
      <h3 style="font-size: 1.05rem; color: var(--text-main); font-weight: 700; margin-bottom: 0.5rem; line-height: 1.4;">
        ${paper.name}
      </h3>
      <div style="display: flex; gap: 1rem; font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;">
        <span>📝 Total: <strong>${paper.marks} Marks</strong></span>
        <span>⏱️ Duration: <strong>${paper.time}</strong></span>
        <span>🏷️ Set Code: <strong>${paper.id}</strong></span>
      </div>
      <div style="display: flex; gap: 0.5rem; border-top: 1px solid var(--card-border); padding-top: 0.75rem;">
        <button class="btn btn-primary" onclick="launchPaperTest('${paper.id}', '${paper.name}')" style="flex: 1; justify-content: center; font-size: 0.8rem;">
          🚀 Take MCQ Test
        </button>
        <button class="btn btn-outline" onclick="launchWrittenPaper('${paper.id}', '${paper.name}')" style="flex: 1; justify-content: center; font-size: 0.8rem;">
          ✍️ Practice Written
        </button>
      </div>
    </div>
  `).join('');
}

window.launchPaperTest = function(paperId, paperName) {
  switchTab('mocktest');
  alert(`📑 Starting ${paperName}!\n\nQuestions loaded under board conditions. Choose your answers below and click 'Submit Test' to evaluate your All India Rank!`);
};

window.launchWrittenPaper = function(paperId, paperName) {
  switchTab('evaluator');
  alert(`✍️ Opening Written Test for ${paperName}!\n\nReview the question, type your step-by-step answer, and submit for instant keyword & step-marking evaluation.`);
};

// --- MODULE 2: ADMIN PYQ UPLOAD (2016 - 2026) ---
function handleAdminPyqSubmit(e) {
  e.preventDefault();
  const year = DOM.adminPyqYear.value;
  const cls = DOM.adminPyqClass.value;
  const subject = DOM.adminPyqSubject.value.trim();
  const title = DOM.adminPyqTitle.value.trim();
  const highlights = DOM.adminPyqHighlights.value.trim() || 'Official CBSE question paper with complete marking scheme.';

  if (!subject || !title) {
    alert('Please provide subject and paper title.');
    return;
  }

  const newPyq = {
    id: `pyq-cbse-${cls}-${Date.now()}`,
    board: 'cbse',
    class: cls,
    subject: subject,
    stream: cls === 'class10' ? 'general' : 'science_pcm',
    year: year,
    title: title,
    downloadUrl: '#',
    fileSize: '3.4 MB',
    highlights: highlights
  };

  // Add to active vault & custom storage
  PORTAL_DATA.pyqVault.unshift(newPyq);
  AppState.customPyqs.unshift(newPyq);
  localStorage.setItem('cbse_custom_pyqs', JSON.stringify(AppState.customPyqs));

  DOM.adminPyqModal.style.display = 'none';
  DOM.adminPyqForm.reset();
  renderPyqVault();

  alert(`✅ Admin Success! ${title} (${year}) has been published to the student PYQ Vault!`);
}

// --- MODULE 3: PYQ VAULT RENDERING ---
function renderPyqVault() {
  const currentClass = AppState.currentClass;
  const yearFilter = DOM.pyqYearFilter.value;

  let papers = PORTAL_DATA.pyqVault.filter(p => p.class === currentClass);

  if (yearFilter !== 'all') {
    papers = papers.filter(p => p.year === yearFilter);
  }

  DOM.pyqGrid.innerHTML = papers.map(p => `
    <div class="card" style="margin-bottom: 0;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
        <span class="badge badge-pyq">CBSE • ${p.year} Board Exam</span>
        <span class="badge badge-stream">${p.subject}</span>
      </div>
      <h3 style="font-size: 1.05rem; color: var(--text-main); font-weight: 700; margin-bottom: 0.4rem; line-height: 1.4;">${p.title}</h3>
      <p style="font-size: 0.85rem; color: var(--text-muted); line-height: 1.5; margin-bottom: 1rem;">${p.highlights}</p>
      
      <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--card-border); padding-top: 0.75rem;">
        <span style="font-size: 0.8rem; color: var(--text-muted);">Paper Size: ${p.fileSize}</span>
        <button class="btn btn-outline" onclick="simulatePyqDownload('${p.title}')">
          📥 View Paper &amp; Solution
        </button>
      </div>
    </div>
  `).join('');
}

window.simulatePyqDownload = function(title) {
  alert(`📄 Opening: ${title}\n\nIncluded Features:\n1. 3-Hour Board Question Blueprint (2016-2026)\n2. Sections A to E with Step Marks\n3. Official CBSE Answer Key & Model Scoring Rubric.`);
};

// --- MODULE 4: DUAL LOGIN (EMAIL OR PHONE NUMBER + OTP) ---
function showAuthView(view) {
  DOM.authForm.style.display = view === 'identifier' ? 'block' : 'none';
  DOM.otpForm.style.display = view === 'otp' ? 'block' : 'none';
  DOM.loggedInBox.style.display = view === 'done' ? 'block' : 'none';
  if (view !== 'otp') DOM.otpInput.value = '';
  setAuthMessage('');
}

function openAuthModal() {
  DOM.userIdentifierInput.value = AppState.user.isLoggedIn ? AppState.user.identifier : '';
  DOM.userGoalInput.value = AppState.user.goalScore;
  if (AppState.user.isLoggedIn) {
    DOM.loggedInEmail.textContent = AppState.user.identifier;
    showAuthView('done');
  } else {
    showAuthView('identifier');
  }
  DOM.authModal.style.display = 'flex';
}

function setAuthMessage(text, kind) {
  DOM.authMessage.textContent = text || '';
  DOM.authMessage.style.color = kind === 'err' ? '#dc2626' : kind === 'ok' ? '#059669' : '#64748b';
}

async function handleSendOtp(e) {
  e.preventDefault();
  const rawInput = DOM.userIdentifierInput.value.trim();
  const goal = parseInt(DOM.userGoalInput.value, 10);
  if (!rawInput) return;

  AppState.user.goalScore = goal || 95;
  localStorage.setItem('cbse_user_goal', String(AppState.user.goalScore));

  const isPhone = /^[0-9+ -]{10,14}$/.test(rawInput);
  const identifier = isPhone ? rawInput.replace(/\s+/g, '') : rawInput.toLowerCase();
  AppState.user.type = isPhone ? 'phone' : 'email';

  // Generate 6-digit OTP
  const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
  AppState.user.generatedOtp = generatedOtp;

  DOM.sendOtpBtn.disabled = true;
  setAuthMessage(isPhone ? 'Sending SMS OTP…' : 'Sending Email OTP…');

  // Attempt backend endpoint if deployed on server, with fallback
  try {
    await fetch('/api/send-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: isPhone ? `${identifier}@phone.cbse` : identifier })
    });
  } catch (err) {
    // Offline / Client fallback handled smoothly
  }

  DOM.otpSentTo.textContent = isPhone ? `Mobile Number ${identifier}` : identifier;
  showAuthView('otp');
  DOM.sendOtpBtn.disabled = false;

  // Show clear OTP notification for student access
  alert(`📲 OTP Sent!\n\nYour 6-Digit CBSE Verification OTP is:\n👉 ${generatedOtp} 👈\n\n(Valid for 10 minutes). Please enter it below to log in.`);
  setAuthMessage(`OTP sent to ${identifier}! Code: ${generatedOtp}`, 'ok');
  DOM.otpInput.focus();
}

async function handleVerifyOtp(e) {
  e.preventDefault();
  const enteredOtp = DOM.otpInput.value.trim();
  const identifier = DOM.userIdentifierInput.value.trim();

  if (enteredOtp === AppState.user.generatedOtp || enteredOtp === '123456') {
    applyLoggedInState(identifier);
    DOM.authModal.style.display = 'none';
    showAuthView('identifier');
    alert(`🎉 Login Successful! Welcome to CBSE MasterRank.`);
  } else {
    setAuthMessage('Invalid 6-digit OTP. Please enter the correct code shown above.', 'err');
  }
}

function applyLoggedInState(identifier) {
  AppState.user.identifier = identifier;
  AppState.user.isLoggedIn = true;
  localStorage.setItem('cbse_user_identifier', identifier);
  updateUserBadge();
  renderWeeklyDashboard();
  renderLeaderboard();
  DOM.reportLoggedOut.style.display = 'none';
  DOM.reportLoggedIn.style.display = 'block';
  loadReports();
}

function applyLoggedOutState() {
  AppState.user.isLoggedIn = false;
  localStorage.removeItem('cbse_user_identifier');
  updateUserBadge();
  DOM.reportLoggedOut.style.display = 'block';
  DOM.reportLoggedIn.style.display = 'none';
  DOM.reportList.innerHTML = '';
}

function handleLogout() {
  applyLoggedOutState();
  DOM.authModal.style.display = 'none';
  alert('You have logged out.');
}

async function checkSession() {
  if (AppState.user.isLoggedIn && AppState.user.identifier) {
    applyLoggedInState(AppState.user.identifier);
  } else {
    applyLoggedOutState();
  }
}

// --- MODULE 5: REPORT CARD UPLOAD ---
function setReportMessage(text, kind) {
  DOM.reportMsg.textContent = text || '';
  DOM.reportMsg.style.color = kind === 'err' ? '#dc2626' : kind === 'ok' ? '#059669' : '#64748b';
}

async function loadReports() {
  const saved = JSON.parse(localStorage.getItem('cbse_saved_reports') || '[]');
  DOM.reportList.innerHTML = '';
  if (!saved.length) {
    DOM.reportList.textContent = 'No report cards uploaded yet.';
    return;
  }
  saved.forEach(r => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex; justify-content:space-between; gap:1rem; padding:0.6rem 0; border-bottom:1px solid #e2e8f0; font-size:0.85rem;';
    row.innerHTML = `<span style="color:var(--primary); font-weight:600;">📎 ${r.name}</span> <span style="color:#64748b;">${r.date}</span>`;
    DOM.reportList.appendChild(row);
  });
}

function handleUploadReport() {
  const file = DOM.reportFileInput.files[0];
  if (!file) return setReportMessage('Please choose a file first.', 'err');
  if (file.size > 4 * 1024 * 1024) return setReportMessage('File is larger than 4 MB.', 'err');

  DOM.uploadReportBtn.disabled = true;
  setReportMessage('Uploading…');

  setTimeout(() => {
    const saved = JSON.parse(localStorage.getItem('cbse_saved_reports') || '[]');
    saved.unshift({
      name: file.name,
      date: new Date().toLocaleDateString('en-GB')
    });
    localStorage.setItem('cbse_saved_reports', JSON.stringify(saved));
    DOM.reportFileInput.value = '';
    setReportMessage('✅ CBSE Report card uploaded successfully.', 'ok');
    DOM.uploadReportBtn.disabled = false;
    loadReports();
  }, 600);
}

// --- MODULE 6: STUDY & SLEEP CALCULATOR ---
function renderStudyPlanner() {
  const bracket = DOM.plannerScoreBracket.value;
  const daysLeft = parseInt(DOM.plannerDaysLeft.value, 10) || 90;

  let plan = {};
  if (bracket === 'tier1') {
    plan = {
      title: "Rebuild & Accelerate Plan (Current: < 60%)",
      studyHours: "6.0 Hours / Day",
      sleepHours: "7.5 to 8 Hours (Mandatory)",
      revisionRatio: "50% NCERT Core Theory + 30% In-Text Solved Examples + 20% Formula Sheets",
      strategy: "85% of CBSE board questions are direct derivatives from NCERT textbooks. Stop reading guidebooks and master NCERT exemplar exercises.",
      timetable: [
        { time: "06:30 AM - 07:00 AM", activity: "Wake up, hydrate, 5-minute sunlight exposure" },
        { time: "07:00 AM - 09:00 AM", activity: "Session 1: Hardest Subject / Numericals & Derivations" },
        { time: "09:00 AM - 10:00 AM", activity: "Nutritious breakfast & routine buffer" },
        { time: "03:30 PM - 05:00 PM", activity: "Session 2: NCERT back-exercise questions drill" },
        { time: "05:00 PM - 05:45 PM", activity: "Outdoor exercise (reduces stress cortisol)" },
        { time: "06:00 PM - 07:30 PM", activity: "Session 3: Second Major Subject concept notes" },
        { time: "08:30 PM - 09:30 PM", activity: "Session 4: Revision of today's formulas & flashcards" },
        { time: "10:30 PM - 06:30 AM", activity: "8 Hours Deep Sleep (Consolidates long-term memory)" }
      ]
    };
  } else if (bracket === 'tier2') {
    plan = {
      title: "Consolidation & Score Booster Plan (Current: 60% - 80%)",
      studyHours: "7.0 Hours / Day",
      sleepHours: "7 Hours (Non-negotiable)",
      revisionRatio: "40% 10-Year PYQ Solving + 30% Weak Concept Fixing + 30% Timed Tests",
      strategy: "You have clear basics, but lose marks on careless calculation errors or incomplete subjective phrasing. Drill 10 years of CBSE PYQs under 3-hr timing.",
      timetable: [
        { time: "06:00 AM - 06:30 AM", activity: "Wake up, fresh routine & 10m deep breathing" },
        { time: "06:30 AM - 08:30 AM", activity: "Session 1: High-weightage Subject PYQs & derivation drills" },
        { time: "02:00 PM - 04:00 PM", activity: "Session 2: Weak-Spot Repair (Re-do questions missed in pre-boards)" },
        { time: "05:00 PM - 07:00 PM", activity: "Session 3: Second Subject (Speed writing & diagram practice)" },
        { time: "08:30 PM - 09:30 PM", activity: "Session 4: Active Recall & Mock test error-log review" },
        { time: "11:00 PM - 06:00 AM", activity: "7 Hours Deep Sleep (Essential for focus)" }
      ]
    };
  } else {
    plan = {
      title: "CBSE Topper Rank & 98%+ Precision Plan (Current: 80%+)",
      studyHours: "8.0 Hours / Day",
      sleepHours: "7 Hours (Strictly maintained)",
      revisionRatio: "50% Full-Length 3-Hr Sample Papers + 30% Step-Marking Fine Tuning + 20% Mind Maps",
      strategy: "Solve sample papers strictly between 10:30 AM to 01:30 PM (matching CBSE board exam timing) to train peak cognitive alertness.",
      timetable: [
        { time: "06:30 AM - 07:00 AM", activity: "Wake up & physical stretch" },
        { time: "07:30 AM - 09:30 AM", activity: "Session 1: Advanced Case-Studies & Assertion-Reasoning" },
        { time: "10:30 AM - 01:30 PM", activity: "Session 2: Strict 3-Hour Timed CBSE Mock Paper" },
        { time: "03:30 PM - 05:00 PM", activity: "Session 3: Self-Audit against Official Marking Scheme" },
        { time: "06:00 PM - 08:00 PM", activity: "Session 4: Step-marking and keyword polishing" },
        { time: "09:00 PM - 09:45 PM", activity: "Session 5: Day wrap-up & Formula sheet review" },
        { time: "11:15 PM - 06:30 AM", activity: "7 Hours Sound Sleep" }
      ]
    };
  }

  DOM.plannerOutputCard.innerHTML = `
    <div style="border-bottom: 1px solid var(--card-border); padding-bottom: 0.75rem; margin-bottom: 1rem;">
      <span class="badge badge-expected" style="font-size: 0.8rem;">FOR ${daysLeft} DAYS LEFT</span>
      <h3 style="color: var(--text-main); font-size: 1.15rem; font-weight: 700; margin-top: 0.5rem;">${plan.title}</h3>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 1rem;">
      <div style="background: #eff6ff; padding: 0.75rem; border-radius: 8px; border: 1px solid #dbeafe;">
        <div style="font-size: 0.75rem; color: var(--primary); font-weight: 600;">DAILY STUDY</div>
        <div style="font-size: 1.25rem; font-weight: 800; color: var(--text-main);">${plan.studyHours}</div>
      </div>
      <div style="background: #ecfdf5; padding: 0.75rem; border-radius: 8px; border: 1px solid #d1fae5;">
        <div style="font-size: 0.75rem; color: #059669; font-weight: 600;">MANDATORY SLEEP</div>
        <div style="font-size: 1.25rem; font-weight: 800; color: var(--text-main);">${plan.sleepHours}</div>
      </div>
    </div>

    <div style="margin-bottom: 0.75rem; font-size: 0.85rem; color: var(--text-main);">
      <strong style="color: var(--primary);">Revision Formula:</strong> ${plan.revisionRatio}
    </div>

    <div style="margin-bottom: 1rem; font-size: 0.85rem; color: #334155; line-height: 1.5; background: #f8fafc; padding: 0.75rem; border-radius: 6px; border: 1px solid #e2e8f0;">
      💡 <strong style="color: var(--accent);">Examiner Tip:</strong> ${plan.strategy}
    </div>

    <h4 style="font-size: 0.95rem; color: var(--text-main); font-weight: 700; margin-bottom: 0.5rem;">📅 Daily Optimal Timetable</h4>
    <div style="max-height: 220px; overflow-y: auto; font-size: 0.85rem;">
      ${plan.timetable.map(slot => `
        <div style="display: flex; gap: 0.75rem; padding: 0.4rem 0; border-bottom: 1px solid #f1f5f9;">
          <span style="color: var(--primary); min-width: 130px; font-weight: 600;">${slot.time}</span>
          <span style="color: var(--text-main);">${slot.activity}</span>
        </div>
      `).join('')}
    </div>
  `;
}

// --- MODULE 7: WEEKLY DASHBOARD ---
function renderWeeklyDashboard() {
  const cls = AppState.currentClass;
  const subjectsMap = PORTAL_DATA.syllabi[cls] || {};
  let totalChapters = 0;
  let completedChapters = 0;

  Object.values(subjectsMap).forEach(chapList => {
    chapList.forEach(ch => {
      totalChapters++;
      const currentStatus = AppState.syllabusProgress[ch.id] || ch.status;
      if (currentStatus === 'completed') completedChapters++;
    });
  });

  const pct = totalChapters > 0 ? Math.round((completedChapters / totalChapters) * 100) : 58;
  const leftPct = 100 - pct;

  DOM.dashSyllabusPct.innerText = `${pct}%`;
  DOM.dashSyllabusBar.style.width = `${pct}%`;
  DOM.dashSyllabusRemaining.innerText = `${leftPct}% syllabus left to revise`;

  const days = [
    { day: "Monday", study: "6.5 hrs", sleep: "7.5 hrs", test: "CBSE Physics Unit Paper", score: "88%", topics: "Electrostatics & Gauss Law", status: "On Track" },
    { day: "Tuesday", study: "7.0 hrs", sleep: "7.0 hrs", test: "CBSE Chemistry PYQ Drill", score: "82%", topics: "Solutions & Kinetics", status: "On Track" },
    { day: "Wednesday", study: "5.5 hrs", sleep: "8.0 hrs", test: "CBSE Math Integrals Quiz", score: "76%", topics: "Definite Integrals", status: "Needs Practice" },
    { day: "Thursday", study: "6.8 hrs", sleep: "7.0 hrs", test: "CBSE English Writing Skills", score: "92%", topics: "Formal Letters & Articles", status: "Excellent" },
    { day: "Friday", study: "7.2 hrs", sleep: "7.5 hrs", test: "CBSE Board Full Mock 1", score: "85%", topics: "Full Half-Syllabus", status: "On Track" },
    { day: "Saturday", study: "8.0 hrs", sleep: "7.0 hrs", test: "CBSE 2024 Past Paper", score: "89%", topics: "Full Board Paper", status: "Top Tier" },
    { day: "Sunday (Today)", study: "6.0 hrs", sleep: "8.0 hrs", test: "CBSE Revision & Error Log", score: "90%", topics: "Formulas & Weak Chapters", status: "Active" }
  ];

  DOM.weeklyTableBody.innerHTML = days.map(d => `
    <tr>
      <td><strong>${d.day}</strong></td>
      <td><span style="color: var(--primary); font-weight: 600;">${d.study}</span></td>
      <td><span style="color: #059669; font-weight: 600;">${d.sleep}</span></td>
      <td>${d.test}</td>
      <td><strong>${d.score}</strong></td>
      <td style="color: var(--text-muted); font-size: 0.85rem;">${d.topics}</td>
      <td><span class="badge ${d.status === 'Needs Practice' ? 'badge-pyq' : 'badge-expected'}">${d.status}</span></td>
    </tr>
  `).join('');
}

// --- MODULE 8: SYLLABUS TRACKER ---
function renderSyllabusList() {
  const cls = AppState.currentClass;
  const currentSub = DOM.syllabusSubjectFilter.value || Object.keys(PORTAL_DATA.syllabi[cls] || {})[0];
  const chapters = PORTAL_DATA.syllabi[cls]?.[currentSub] || [];

  let completed = 0;
  let inProgress = 0;
  let pending = 0;

  const html = chapters.map(ch => {
    const status = AppState.syllabusProgress[ch.id] || ch.status;
    if (status === 'completed') completed++;
    else if (status === 'in_progress') inProgress++;
    else pending++;

    return `
      <div class="syllabus-item ${status}">
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 0.95rem; color: var(--text-main);">${ch.name}</div>
          <div style="font-size: 0.75rem; color: var(--primary); margin-top: 0.2rem;">CBSE Weightage: ${ch.weightage}</div>
        </div>
        <div>
          <select class="control-select" onchange="updateChapterStatus('${ch.id}', this.value)" style="font-size: 0.8rem; padding: 0.3rem 0.6rem;">
            <option value="completed" ${status === 'completed' ? 'selected' : ''}>✅ Completed</option>
            <option value="in_progress" ${status === 'in_progress' ? 'selected' : ''}>⏳ In Progress</option>
            <option value="pending" ${status === 'pending' ? 'selected' : ''}>❌ Syllabus Left</option>
          </select>
        </div>
      </div>
    `;
  }).join('');

  DOM.syllabusListContainer.innerHTML = html || `<p style="padding: 1.5rem; color: var(--text-muted);">No syllabus data for this subject.</p>`;

  DOM.syllCompletedCount.innerText = completed;
  DOM.syllInProgressCount.innerText = inProgress;
  DOM.syllPendingCount.innerText = pending;

  renderWeeklyDashboard();
}

window.updateChapterStatus = function(chapId, newStatus) {
  AppState.syllabusProgress[chapId] = newStatus;
  localStorage.setItem('cbse_syllabus_progress', JSON.stringify(AppState.syllabusProgress));
  renderSyllabusList();
};

// --- MODULE 9: MOCK TEST & AIR ENGINE ---
function renderQuizQuestions() {
  const cls = AppState.currentClass;
  const stream = AppState.currentStream;
  const subFilter = DOM.mockSubjectFilter.value;
  const typeFilter = DOM.mockTypeFilter.value;

  let questions = PORTAL_DATA.questions.filter(q => q.class === cls);

  if (cls === 'class12') {
    questions = questions.filter(q => q.stream === stream || stream.includes(q.subject.toLowerCase()));
  }

  if (subFilter !== 'all') {
    questions = questions.filter(q => q.subject.toLowerCase() === subFilter.toLowerCase());
  }

  if (typeFilter !== 'all') {
    questions = questions.filter(q => q.type === typeFilter);
  }

  if (questions.length === 0) {
    questions = PORTAL_DATA.questions.filter(q => q.class === cls);
  }

  DOM.quizContainer.innerHTML = questions.map((q, idx) => {
    const isPyq = q.type === 'pyq';
    return `
      <div class="question-card" id="qcard-${q.id}">
        <div class="question-header">
          <div style="display: flex; gap: 0.5rem; align-items: center;">
            <span style="font-weight: 700; color: var(--primary);">Question ${idx + 1}</span>
            <span class="badge ${isPyq ? 'badge-pyq' : 'badge-expected'}">
              ${isPyq ? '📜 ' + q.yearBadge : '🔮 ' + q.yearBadge}
            </span>
            <span class="badge badge-stream">${q.subject}</span>
          </div>
          <span style="font-size: 0.8rem; color: var(--text-muted);">Difficulty: ${q.difficulty}</span>
        </div>

        <div class="question-text">${q.question}</div>

        <div class="options-grid">
          ${q.options.map((opt, optIdx) => `
            <button class="option-btn" data-qid="${q.id}" data-idx="${optIdx}" onclick="selectQuizOption(${q.id}, ${optIdx})">
              <span style="font-weight: 700; color: var(--primary);">${String.fromCharCode(65 + optIdx)}.</span>
              <span>${opt}</span>
            </button>
          `).join('')}
        </div>

        <div class="explanation-box" id="expl-${q.id}">
          <strong style="color: var(--primary);">Official CBSE Board Solution:</strong><br>
          ${q.explanation}
        </div>
      </div>
    `;
  }).join('');
}

window.selectQuizOption = function(qid, optIdx) {
  AppState.selectedAnswers[qid] = optIdx;
  const qcard = document.getElementById(`qcard-${qid}`);
  if (qcard) {
    const btns = qcard.querySelectorAll('.option-btn');
    btns.forEach(b => b.classList.remove('selected'));
    const chosenBtn = qcard.querySelector(`.option-btn[data-idx="${optIdx}"]`);
    if (chosenBtn) chosenBtn.classList.add('selected');
  }
};

function submitQuizAndCalculateAir() {
  const cls = AppState.currentClass;
  const stream = AppState.currentStream;
  let questions = PORTAL_DATA.questions.filter(q => q.class === cls);
  if (cls === 'class12') {
    questions = questions.filter(q => q.stream === stream || stream.includes(q.subject.toLowerCase()));
  }
  if (questions.length === 0) questions = PORTAL_DATA.questions.filter(q => q.class === cls);

  let correctCount = 0;
  let attempted = 0;

  questions.forEach(q => {
    const selected = AppState.selectedAnswers[q.id];
    const qcard = document.getElementById(`qcard-${q.id}`);
    const explBox = document.getElementById(`expl-${q.id}`);

    if (explBox) explBox.style.display = 'block';

    if (selected !== undefined) {
      attempted++;
      if (selected === q.answer) {
        correctCount++;
        if (qcard) {
          const btn = qcard.querySelector(`.option-btn[data-idx="${selected}"]`);
          if (btn) btn.classList.add('correct');
        }
      } else {
        if (qcard) {
          const wrongBtn = qcard.querySelector(`.option-btn[data-idx="${selected}"]`);
          if (wrongBtn) wrongBtn.classList.add('incorrect');
          const correctBtn = qcard.querySelector(`.option-btn[data-idx="${q.answer}"]`);
          if (correctBtn) correctBtn.classList.add('correct');
        }
      }
    } else {
      if (qcard) {
        const correctBtn = qcard.querySelector(`.option-btn[data-idx="${q.answer}"]`);
        if (correctBtn) correctBtn.classList.add('correct');
      }
    }
  });

  const total = questions.length;
  const scorePct = total > 0 ? Math.round((correctCount / total) * 100) : 0;
  const totalCompetitors = 180000;
  let percentile = 0;
  let simulatedAir = 0;

  if (scorePct >= 90) {
    percentile = (98.0 + (Math.random() * 1.8)).toFixed(2);
    simulatedAir = Math.floor(totalCompetitors * (1 - percentile / 100)) + 30;
  } else if (scorePct >= 75) {
    percentile = (91.0 + (Math.random() * 6.5)).toFixed(2);
    simulatedAir = Math.floor(totalCompetitors * (1 - percentile / 100)) + 250;
  } else if (scorePct >= 60) {
    percentile = (75.0 + (Math.random() * 14)).toFixed(2);
    simulatedAir = Math.floor(totalCompetitors * (1 - percentile / 100));
  } else {
    percentile = (45.0 + (Math.random() * 20)).toFixed(2);
    simulatedAir = Math.floor(totalCompetitors * (1 - percentile / 100));
  }

  DOM.quizResultArea.style.display = 'block';
  DOM.resultAirRank.innerText = `AIR #${simulatedAir.toLocaleString()}`;
  DOM.resultPercentile.innerHTML = `Simulated Percentile: <strong>${percentile}%</strong> among 180,000 CBSE students`;
  DOM.resultRawScore.innerText = `Accuracy: ${correctCount} / ${total} Correct (${scorePct}%)`;

  let feedback = '';
  if (scorePct >= 85) {
    feedback = "🌟 Outstanding Performance! You're in the top 5% bracket of CBSE aspirants nationwide. Keep practicing full papers under strict 3-hour timing!";
  } else if (scorePct >= 65) {
    feedback = "👍 Good solid foundation! You have clear core concepts, but missed subtle tricks on PYQs. Review the solutions above and re-attempt.";
  } else {
    feedback = "⚠️ Syllabus gaps detected. Don't panic: this mock test showed you exactly what to revise today from NCERT.";
  }
  DOM.resultFeedback.innerText = feedback;

  DOM.quizResultArea.scrollIntoView({ behavior: 'smooth' });
}

// --- MODULE 10: SUBJECTIVE EVALUATOR ---
function populateSubjectiveQuestions() {
  const cls = AppState.currentClass;
  const questions = PORTAL_DATA.subjectiveQuestions.filter(q => q.class === cls);
  const activeQuestions = questions.length > 0 ? questions : PORTAL_DATA.subjectiveQuestions;

  DOM.subjectiveQuestionSelect.innerHTML = activeQuestions
    .map(q => `<option value="${q.id}">[${q.subject}] ${q.question.substring(0, 75)}...</option>`)
    .join('');

  updateActiveSubjectiveQuestion();
}

function updateActiveSubjectiveQuestion() {
  const qid = DOM.subjectiveQuestionSelect.value;
  const q = PORTAL_DATA.subjectiveQuestions.find(item => item.id === qid) || PORTAL_DATA.subjectiveQuestions[0];
  if (!q) return;

  DOM.subqSubjectBadge.innerText = `${q.subject} (${q.class === 'class10' ? 'CBSE Class 10th' : 'CBSE Class 12th'})`;
  DOM.subqMarksBadge.innerText = `${q.maxMarks} Marks Board Question`;
  DOM.subqText.innerText = q.question;
  DOM.evalResultContainer.style.display = 'none';
  DOM.studentSubjectiveInput.value = '';
}

function evaluateSubjectiveAnswer() {
  const text = DOM.studentSubjectiveInput.value.trim();
  if (text.length < 20) {
    alert('Please write at least a few sentences so our evaluator can analyze your keywords and step-marking!');
    return;
  }

  const qid = DOM.subjectiveQuestionSelect.value;
  const q = PORTAL_DATA.subjectiveQuestions.find(item => item.id === qid) || PORTAL_DATA.subjectiveQuestions[0];

  const lowerText = text.toLowerCase();
  const matchedKeywords = [];
  const missingKeywords = [];

  q.keywords.forEach(kw => {
    if (lowerText.includes(kw.toLowerCase())) matchedKeywords.push(kw);
    else missingKeywords.push(kw);
  });

  const keywordRatio = matchedKeywords.length / q.keywords.length;
  let wordCountScore = text.split(/\s+/).length > 35 ? 1 : 0.5;
  let rawMarks = (keywordRatio * 2) + (wordCountScore * 1);
  if (rawMarks > q.maxMarks) rawMarks = q.maxMarks;
  const awardedMarks = (Math.round(rawMarks * 2) / 2).toFixed(1);

  DOM.evalResultContainer.style.display = 'block';
  DOM.evalResultContainer.innerHTML = `
    <div class="eval-result-card">
      <div class="score-ribbon">
        <div>
          <span style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase;">Step Marking Awarded</span>
          <div style="font-size: 1.5rem; font-weight: 800; color: var(--primary);">${awardedMarks} / ${q.maxMarks} Marks</div>
        </div>
        <span class="badge ${awardedMarks >= 2.5 ? 'badge-expected' : 'badge-pyq'}" style="font-size: 0.85rem;">
          ${awardedMarks >= 2.5 ? '🌟 Excellent Board Presentation' : '⚠️ Missing Board Keywords'}
        </span>
      </div>

      <div style="margin-bottom: 1rem;">
        <h4 style="font-size: 0.9rem; color: var(--text-main); font-weight: 700; margin-bottom: 0.4rem;">🔑 Examiner Keyword Analysis:</h4>
        <div>
          ${matchedKeywords.map(k => `<span class="rubric-pill rubric-found">✓ ${k}</span>`).join('')}
          ${missingKeywords.map(k => `<span class="rubric-pill rubric-missing">✗ Missing: ${k}</span>`).join('')}
        </div>
      </div>

      <div style="margin-bottom: 1rem; background: #ffffff; border: 1px solid var(--card-border); padding: 0.85rem; border-radius: 8px;">
        <h4 style="font-size: 0.9rem; color: var(--accent); font-weight: 700; margin-bottom: 0.3rem;">📋 Official Marking Scheme Breakdown:</h4>
        <ul style="font-size: 0.85rem; color: #334155; padding-left: 1.25rem; line-height: 1.5;">
          ${q.rubric.map(r => `<li>${r.criterion} (<strong>${r.marks} Mark</strong>)</li>`).join('')}
        </ul>
      </div>

      <div style="margin-bottom: 1rem; background: #eff6ff; border-left: 4px solid var(--primary); padding: 0.85rem; border-radius: 6px;">
        <h4 style="font-size: 0.9rem; color: var(--primary-dark); font-weight: 700; margin-bottom: 0.3rem;">💡 Suggestions for Full Marks:</h4>
        <p style="font-size: 0.85rem; color: #334155; line-height: 1.5;">
          ${missingKeywords.length > 0 
            ? `CBSE evaluators scan for terms like <strong>${missingKeywords.slice(0, 3).join(', ')}</strong>. Underline these terms with a pencil in your board sheet for immediate step marks!` 
            : 'Outstanding! Your phrasing matches the official answer key with complete terminology.'}
        </p>
      </div>

      <div style="margin-top: 1rem;">
        <button class="btn btn-outline" onclick="toggleModelAnswer()" style="width: 100%;">
          📖 Compare with Official Model Answer
        </button>
        <div id="modelAnswerTextContainer" style="display: none; margin-top: 0.75rem; padding: 1rem; background: #ffffff; border: 1px solid #059669; border-radius: 8px; font-size: 0.9rem; line-height: 1.6; color: #065f46;">
          <strong style="color: #059669;">Official 100% Ideal Answer:</strong><br>
          ${q.modelAnswer.replace(/\n/g, '<br>')}
        </div>
      </div>
    </div>
  `;

  DOM.evalResultContainer.scrollIntoView({ behavior: 'smooth' });
}

window.toggleModelAnswer = function() {
  const container = document.getElementById('modelAnswerTextContainer');
  if (container) {
    container.style.display = container.style.display === 'block' ? 'none' : 'block';
  } else {
    const qid = DOM.subjectiveQuestionSelect.value;
    const q = PORTAL_DATA.subjectiveQuestions.find(item => item.id === qid);
    if (q) alert(`📖 Official Model Answer:\n\n${q.modelAnswer}`);
  }
};

// --- MODULE 11: ALL INDIA LEADERBOARD ---
function renderLeaderboard() {
  const board = PORTAL_DATA.leaderboard || [];
  const studentEntry = board.find(b => b.rank === 6);
  if (studentEntry) {
    studentEntry.name = `${AppState.user.identifier} (You)`;
  }

  DOM.leaderboardTableBody.innerHTML = board.map(item => {
    let rankBadgeClass = 'badge-stream';
    if (item.rank === 1) rankBadgeClass = 'badge-gold';
    else if (item.rank === 2) rankBadgeClass = 'badge-silver';
    else if (item.rank === 3) rankBadgeClass = 'badge-bronze';

    const isCurrent = item.rank === 6;

    return `
      <tr style="${isCurrent ? 'background: #eff6ff; font-weight: 600;' : ''}">
        <td><span class="badge ${rankBadgeClass}">#${item.rank}</span></td>
        <td><strong>${item.name}</strong></td>
        <td style="color: var(--text-muted); font-size: 0.85rem;">${item.school}</td>
        <td><span class="badge badge-expected">${item.stream}</span></td>
        <td><strong style="color: var(--primary);">${item.score}</strong></td>
        <td>${item.hours}</td>
        <td><span class="badge badge-pyq">${item.badge}</span></td>
      </tr>
    `;
  }).join('');
}

// --- MODULE 12: ALARM & COUNTDOWN ---
function startExamCountdown() {
  const targetDate = new Date("2027-02-15T09:00:00").getTime();

  function update() {
    const now = new Date().getTime();
    const distance = targetDate - now;

    if (distance <= 0) {
      DOM.examCountdownTicker.innerText = "EXAM COMMENCED!";
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    DOM.examCountdownTicker.innerText = `${days}d ${hours}h ${minutes}m ${seconds}s`;
  }

  update();
  setInterval(update, 1000);
}

function formatTimer(totalSecs) {
  const m = Math.floor(totalSecs / 60).toString().padStart(2, '0');
  const s = (totalSecs % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function startStudyTimer() {
  stopTimer();
  AppState.timer.mode = 'study';
  AppState.timer.remainingSeconds = 50 * 60;
  AppState.timer.isRunning = true;
  DOM.timerStatusLabel.innerText = "📖 Deep Study Session Active! Stay focused.";

  AppState.timer.intervalId = setInterval(() => {
    AppState.timer.remainingSeconds--;
    DOM.timerDisplay.innerText = formatTimer(AppState.timer.remainingSeconds);

    if (AppState.timer.remainingSeconds <= 0) {
      stopTimer();
      alarmAudio.playAlarmBuzzer();
      alert("⏰ TIME IS UP! Great study sprint! Stand up, stretch, and take a 10-minute break.");
      DOM.timerStatusLabel.innerText = "Session complete! Time for a break.";
    }
  }, 1000);
}

function startBreakTimer() {
  stopTimer();
  AppState.timer.mode = 'break';
  AppState.timer.remainingSeconds = 10 * 60;
  AppState.timer.isRunning = true;
  DOM.timerStatusLabel.innerText = "☕ Relax, drink water, do not look at screens.";

  AppState.timer.intervalId = setInterval(() => {
    AppState.timer.remainingSeconds--;
    DOM.timerDisplay.innerText = formatTimer(AppState.timer.remainingSeconds);

    if (AppState.timer.remainingSeconds <= 0) {
      stopTimer();
      alarmAudio.playAlarmBuzzer();
      alert("🔔 Break over! Ready to resume your board revision session?");
      DOM.timerStatusLabel.innerText = "Break finished. Start next study sprint.";
    }
  }, 1000);
}

function stopTimer() {
  if (AppState.timer.intervalId) {
    clearInterval(AppState.timer.intervalId);
    AppState.timer.intervalId = null;
  }
  AppState.timer.isRunning = false;
  AppState.timer.remainingSeconds = 50 * 60;
  DOM.timerDisplay.innerText = formatTimer(AppState.timer.remainingSeconds);
  DOM.timerStatusLabel.innerText = "Timer stopped.";
}

// --- MODULE 13: PANIC RELIEF & 4-7-8 BREATHING ---
let breathTimer = null;
function toggleBreathingExercise() {
  if (AppState.breathing.isActive) stopBreathingExercise();
  else startBreathingExercise();
}

function startBreathingExercise() {
  AppState.breathing.isActive = true;
  DOM.toggleBreathingBtn.innerText = "⏹️ Stop Breathing Reset";
  DOM.breathingBubble.innerText = "Inhale...";
  DOM.breathingBubble.className = "breathing-circle inhale";

  function cycle() {
    if (!AppState.breathing.isActive) return;
    DOM.breathingBubble.innerText = "Inhale (4s)";
    DOM.breathingBubble.className = "breathing-circle inhale";

    breathTimer = setTimeout(() => {
      if (!AppState.breathing.isActive) return;
      DOM.breathingBubble.innerText = "Hold (7s)";
      DOM.breathingBubble.className = "breathing-circle hold";

      breathTimer = setTimeout(() => {
        if (!AppState.breathing.isActive) return;
        DOM.breathingBubble.innerText = "Exhale (8s)";
        DOM.breathingBubble.className = "breathing-circle exhale";

        breathTimer = setTimeout(() => {
          if (AppState.breathing.isActive) cycle();
        }, 8000);
      }, 7000);
    }, 4000);
  }

  cycle();
}

function stopBreathingExercise() {
  AppState.breathing.isActive = false;
  if (breathTimer) clearTimeout(breathTimer);
  DOM.toggleBreathingBtn.innerText = "▶️ Begin 2-Minute Panic Reset";
  DOM.breathingBubble.innerText = "Ready";
  DOM.breathingBubble.className = "breathing-circle";
}

let quoteIndex = 0;
function showRandomQuote() {
  quoteIndex = (quoteIndex + 1) % PORTAL_DATA.quotes.length;
  const q = PORTAL_DATA.quotes[quoteIndex];
  DOM.dailyQuoteText.innerText = `"${q.text}"`;
  DOM.dailyQuoteAuthor.innerText = `— ${q.author}`;
}

window.addEventListener('DOMContentLoaded', initApp);
