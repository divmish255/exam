# CBSE MasterRank AI - Class 10th & 12th Board Exam Hub (2016 - 2026)

A modern, high-contrast, dual-color light portal tailored exclusively for **CBSE Class 10th and 12th** students. Live on Vercel at `https://exam-tracker-eta.vercel.app/`.

---

## 🌟 What's New in this Release

1. **Clean Dual-Color Light Themes**:
   - High-contrast, glare-free light mode with 3 selectable palettes:
     - ☀️ **Sky & Ivory Light** (Default)
     - 🌸 **Lavender & Rose Mist**
     - 🍃 **Mint & Cream**
2. **CBSE Class 10th & 12th Exclusive**:
   - Streamlined specifically for CBSE syllabus, blueprints, and marking criteria.
   - Streams: Science (PCM & PCB), Commerce, and Humanities.
3. **Dual Login (Email ID or 10-Digit Mobile Number) + 6-Digit OTP**:
   - Sign in with either an email address or mobile phone number.
   - Automatic 6-digit OTP generation and verification to save weekly reports, mock test results, and All India Rank.
4. **100 CBSE Question Papers Repository**:
   - Comprehensive matrix of 100 curated CBSE question papers across subjects.
   - Filterable by subject and paper type (Full Mock, Sectional Drill, Blueprint Specimen, Case Study).
   - Launch directly into MCQ tests or Written evaluation.
5. **10-Year CBSE PYQ Vault (2016 - 2026) + Admin Upload Portal**:
   - Complete archive of official CBSE past papers and marking schemes from 2016 to 2026.
   - In-app **Admin PYQ Upload modal** to publish new papers and solutions directly into the vault.
6. **Written Answer Step-by-Step Evaluator**:
   - Type answers to CBSE 3-mark and 5-mark subjective questions.
   - Automatic step-marking evaluation, examiner keywords check, and model answers.
7. **Study, Sleep & Revision Calculator**:
   - Performance-based study timetable according to current score (<60%, 60-80%, >80%).
8. **Study Alarm & Offline Audio Buzzer**:
   - Web Audio API alarm and 50-minute Pomodoro study focus timer.
9. **Panic SOS & 4-7-8 Breathing Calmer**:
   - Quick anxiety reset with animated breathing pacer and grounding techniques.

---

## 🚀 How to Update Your Live Vercel Site (`exam-tracker-eta.vercel.app`)

### Option A: Upload Directly via GitHub Web (No Terminal Needed)
1. Open your repository on [GitHub.com](https://github.com/) that is connected to `exam-tracker-eta.vercel.app`.
2. Click **Add file** ➔ **Upload files**.
3. Drag and drop the updated files (`index.html`, `styles.css`, `app.js`, `data.js`, `package.json`, `vercel.json`, `README.md`).
4. Click **Commit changes**.
5. Vercel will automatically detect the commit and re-deploy your site in under 30 seconds!

### Option B: Push via Git Terminal
```bash
git add .
git commit -m "Update CBSE MasterRank: Light dual-color themes, OTP login, 100 question papers, PYQ vault 2016-2026"
git push origin main
```

---

## 🛠️ Local Testing
Simply open `index.html` in any modern web browser or run:
```bash
npx serve .
```

---
*Built for CBSE Class 10th and 12th Board Exam Aspirants.*
