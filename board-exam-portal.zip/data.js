// CBSE MasterRank Data Engine (Exclusively for CBSE Class 10th & 12th: 2016 - 2026)
const PORTAL_DATA = {
  board: { id: 'cbse', name: 'CBSE (Central Board of Secondary Education)' },

  classes: [
    { id: 'class10', name: 'CBSE Class 10th (Secondary School Examination)' },
    { id: 'class12', name: 'CBSE Class 12th (Senior Secondary School)' }
  ],

  streams: {
    class10: [
      { id: 'general', name: 'CBSE Class 10 All Subjects (Science, Math Standard/Basic, SST, English, Comp)' }
    ],
    class12: [
      { id: 'science_pcm', name: 'CBSE Science PCM (Physics, Chemistry, Maths, English, Comp. Sci/PE)' },
      { id: 'science_pcb', name: 'CBSE Science PCB (Physics, Chemistry, Biology, English, Psychology/PE)' },
      { id: 'commerce', name: 'CBSE Commerce (Accountancy, Business Studies, Economics, Applied Maths)' },
      { id: 'humanities', name: 'CBSE Humanities (History, Political Science, Geography, Economics, Psychology)' }
    ]
  },

  syllabi: {
    class10: {
      'Science': [
        { id: 'sc1', name: 'Chemical Reactions & Equations', weightage: '6 Marks', status: 'completed' },
        { id: 'sc2', name: 'Acids, Bases & Salts', weightage: '6 Marks', status: 'completed' },
        { id: 'sc3', name: 'Metals & Non-Metals', weightage: '7 Marks', status: 'in_progress' },
        { id: 'sc4', name: 'Carbon & its Compounds', weightage: '8 Marks', status: 'pending' },
        { id: 'sc5', name: 'Life Processes', weightage: '9 Marks', status: 'completed' },
        { id: 'sc6', name: 'Control & Coordination', weightage: '6 Marks', status: 'in_progress' },
        { id: 'sc7', name: 'How do Organisms Reproduce?', weightage: '7 Marks', status: 'pending' },
        { id: 'sc8', name: 'Heredity & Evolution', weightage: '5 Marks', status: 'pending' },
        { id: 'sc9', name: 'Light - Reflection & Refraction', weightage: '10 Marks', status: 'in_progress' },
        { id: 'sc10', name: 'The Human Eye & Colourful World', weightage: '5 Marks', status: 'completed' },
        { id: 'sc11', name: 'Electricity', weightage: '8 Marks', status: 'pending' },
        { id: 'sc12', name: 'Magnetic Effects of Electric Current', weightage: '6 Marks', status: 'pending' },
        { id: 'sc13', name: 'Our Environment', weightage: '5 Marks', status: 'completed' }
      ],
      'Mathematics': [
        { id: 'm1', name: 'Real Numbers', weightage: '6 Marks', status: 'completed' },
        { id: 'm2', name: 'Polynomials', weightage: '5 Marks', status: 'completed' },
        { id: 'm3', name: 'Pair of Linear Equations in 2 Variables', weightage: '6 Marks', status: 'completed' },
        { id: 'm4', name: 'Quadratic Equations', weightage: '6 Marks', status: 'in_progress' },
        { id: 'm5', name: 'Arithmetic Progressions', weightage: '6 Marks', status: 'in_progress' },
        { id: 'm6', name: 'Triangles', weightage: '9 Marks', status: 'pending' },
        { id: 'm7', name: 'Coordinate Geometry', weightage: '6 Marks', status: 'completed' },
        { id: 'm8', name: 'Introduction to Trigonometry', weightage: '8 Marks', status: 'in_progress' },
        { id: 'm9', name: 'Applications of Trigonometry (Heights & Distances)', weightage: '4 Marks', status: 'pending' },
        { id: 'm10', name: 'Circles', weightage: '6 Marks', status: 'pending' },
        { id: 'm11', name: 'Areas Related to Circles', weightage: '5 Marks', status: 'pending' },
        { id: 'm12', name: 'Surface Areas & Volumes', weightage: '6 Marks', status: 'pending' },
        { id: 'm13', name: 'Statistics & Probability', weightage: '11 Marks', status: 'completed' }
      ],
      'Social Science': [
        { id: 'sst1', name: 'Rise of Nationalism in Europe', weightage: '6 Marks', status: 'completed' },
        { id: 'sst2', name: 'Nationalism in India', weightage: '7 Marks', status: 'completed' },
        { id: 'sst3', name: 'Resources & Development', weightage: '4 Marks', status: 'completed' },
        { id: 'sst4', name: 'Agriculture & Mineral Resources', weightage: '6 Marks', status: 'in_progress' },
        { id: 'sst5', name: 'Power Sharing & Federalism', weightage: '6 Marks', status: 'completed' },
        { id: 'sst6', name: 'Money and Credit', weightage: '5 Marks', status: 'in_progress' },
        { id: 'sst7', name: 'Globalisation and the Indian Economy', weightage: '5 Marks', status: 'pending' }
      ],
      'English Language & Lit': [
        { id: 'eng1', name: 'A Letter to God & Nelson Mandela', weightage: '8 Marks', status: 'completed' },
        { id: 'eng2', name: 'Two Stories about Flying & Anne Frank', weightage: '8 Marks', status: 'completed' },
        { id: 'eng3', name: 'Formal Letter & Analytical Paragraph Writing', weightage: '10 Marks', status: 'completed' },
        { id: 'eng4', name: 'Grammar: Tenses, Modals & Reported Speech', weightage: '10 Marks', status: 'pending' }
      ],
      'Computer Applications': [
        { id: 'ca1', name: 'Networking: Protocols & Cyber Ethics', weightage: '15 Marks', status: 'completed' },
        { id: 'ca2', name: 'HTML & CSS Web Design', weightage: '25 Marks', status: 'in_progress' },
        { id: 'ca3', name: 'Cyber Safety & Intellectual Property', weightage: '10 Marks', status: 'pending' }
      ]
    },
    class12: {
      'Physics': [
        { id: 'ph1', name: 'Electrostatics & Electric Potential', weightage: '9 Marks', status: 'completed' },
        { id: 'ph2', name: 'Current Electricity', weightage: '7 Marks', status: 'completed' },
        { id: 'ph3', name: 'Magnetic Effects of Current & Magnetism', weightage: '9 Marks', status: 'in_progress' },
        { id: 'ph4', name: 'Electromagnetic Induction & Alternating Currents', weightage: '8 Marks', status: 'in_progress' },
        { id: 'ph5', name: 'Electromagnetic Waves', weightage: '3 Marks', status: 'completed' },
        { id: 'ph6', name: 'Ray Optics & Wave Optics', weightage: '14 Marks', status: 'pending' },
        { id: 'ph7', name: 'Dual Nature of Radiation & Matter', weightage: '6 Marks', status: 'completed' },
        { id: 'ph8', name: 'Atoms and Nuclei', weightage: '8 Marks', status: 'pending' },
        { id: 'ph9', name: 'Semiconductor Electronics', weightage: '7 Marks', status: 'pending' }
      ],
      'Chemistry': [
        { id: 'ch1', name: 'Solutions', weightage: '7 Marks', status: 'completed' },
        { id: 'ch2', name: 'Electrochemistry', weightage: '9 Marks', status: 'completed' },
        { id: 'ch3', name: 'Chemical Kinetics', weightage: '7 Marks', status: 'in_progress' },
        { id: 'ch4', name: 'd and f Block Elements', weightage: '7 Marks', status: 'pending' },
        { id: 'ch5', name: 'Coordination Compounds', weightage: '7 Marks', status: 'pending' },
        { id: 'ch6', name: 'Haloalkanes and Haloarenes', weightage: '6 Marks', status: 'completed' },
        { id: 'ch7', name: 'Alcohols, Phenols and Ethers', weightage: '6 Marks', status: 'in_progress' },
        { id: 'ch8', name: 'Aldehydes, Ketones and Carboxylic Acids', weightage: '8 Marks', status: 'pending' },
        { id: 'ch9', name: 'Amines & Biomolecules', weightage: '13 Marks', status: 'pending' }
      ],
      'Mathematics': [
        { id: 'mt1', name: 'Relations and Functions', weightage: '5 Marks', status: 'completed' },
        { id: 'mt2', name: 'Matrices & Determinants', weightage: '10 Marks', status: 'completed' },
        { id: 'mt3', name: 'Continuity & Differentiability', weightage: '9 Marks', status: 'in_progress' },
        { id: 'mt4', name: 'Application of Derivatives (AOD)', weightage: '8 Marks', status: 'pending' },
        { id: 'mt5', name: 'Integrals (Definite & Indefinite)', weightage: '12 Marks', status: 'pending' },
        { id: 'mt6', name: 'Differential Equations', weightage: '7 Marks', status: 'pending' },
        { id: 'mt7', name: 'Vectors & 3D Geometry', weightage: '14 Marks', status: 'in_progress' },
        { id: 'mt8', name: 'Linear Programming & Probability', weightage: '15 Marks', status: 'completed' }
      ],
      'Biology': [
        { id: 'bio1', name: 'Sexual Reproduction in Flowering Plants', weightage: '7 Marks', status: 'completed' },
        { id: 'bio2', name: 'Human Reproduction & Reproductive Health', weightage: '9 Marks', status: 'completed' },
        { id: 'bio3', name: 'Principles of Inheritance and Variation', weightage: '10 Marks', status: 'in_progress' },
        { id: 'bio4', name: 'Molecular Basis of Inheritance', weightage: '12 Marks', status: 'pending' },
        { id: 'bio5', name: 'Biotechnology: Principles and Processes', weightage: '11 Marks', status: 'pending' },
        { id: 'bio6', name: 'Ecology & Environment', weightage: '14 Marks', status: 'pending' }
      ],
      'Computer Science (Python)': [
        { id: 'cs1', name: 'Python Functions & Exception Handling', weightage: '10 Marks', status: 'completed' },
        { id: 'cs2', name: 'File Handling (Text, Binary, CSV)', weightage: '12 Marks', status: 'completed' },
        { id: 'cs3', name: 'Data Structures: Stacks', weightage: '8 Marks', status: 'in_progress' },
        { id: 'cs4', name: 'Computer Networks & Topology', weightage: '10 Marks', status: 'pending' },
        { id: 'cs5', name: 'SQL Queries, Joins & Interface', weightage: '20 Marks', status: 'pending' }
      ],
      'Accountancy': [
        { id: 'acc1', name: 'Partnership: Fundamentals', weightage: '8 Marks', status: 'completed' },
        { id: 'acc2', name: 'Admission & Retirement of a Partner', weightage: '14 Marks', status: 'in_progress' },
        { id: 'acc3', name: 'Dissolution of Partnership Firm', weightage: '8 Marks', status: 'pending' },
        { id: 'acc4', name: 'Share Capital & Debentures', weightage: '20 Marks', status: 'pending' },
        { id: 'acc5', name: 'Cash Flow Statement (AS-3)', weightage: '8 Marks', status: 'pending' }
      ],
      'Business Studies': [
        { id: 'bst1', name: 'Principles of Management (Fayol & Taylor)', weightage: '7 Marks', status: 'completed' },
        { id: 'bst2', name: 'Planning & Organising', weightage: '16 Marks', status: 'in_progress' },
        { id: 'bst3', name: 'Directing & Controlling', weightage: '15 Marks', status: 'pending' },
        { id: 'bst4', name: 'Financial Management & Markets', weightage: '15 Marks', status: 'pending' },
        { id: 'bst5', name: 'Marketing Management & Consumer Protection', weightage: '15 Marks', status: 'pending' }
      ],
      'Economics': [
        { id: 'eco1', name: 'Macroeconomics: National Income Accounting', weightage: '10 Marks', status: 'completed' },
        { id: 'eco2', name: 'Money and Banking', weightage: '6 Marks', status: 'completed' },
        { id: 'eco3', name: 'Determination of Income & Employment', weightage: '12 Marks', status: 'in_progress' },
        { id: 'eco4', name: 'Government Budget & Balance of Payments', weightage: '12 Marks', status: 'pending' },
        { id: 'eco5', name: 'Indian Economic Development (1947-1990 & Reforms)', weightage: '20 Marks', status: 'pending' }
      ],
      'History': [
        { id: 'his1', name: 'Bricks, Beads and Bones (Harappan Civilisation)', weightage: '7 Marks', status: 'completed' },
        { id: 'his2', name: 'Kings, Farmers and Towns (Early States)', weightage: '8 Marks', status: 'completed' },
        { id: 'his3', name: 'Bhakti-Sufi Traditions & Imperial Vijayanagara', weightage: '15 Marks', status: 'pending' },
        { id: 'his4', name: 'Mahatma Gandhi & the Nationalist Movement', weightage: '10 Marks', status: 'pending' }
      ],
      'Political Science': [
        { id: 'pol1', name: 'The End of Bipolarity', weightage: '6 Marks', status: 'completed' },
        { id: 'pol2', name: 'Contemporary Centres of Power & UN', weightage: '10 Marks', status: 'completed' },
        { id: 'pol3', name: 'Challenges of Nation Building & Politics in India', weightage: '12 Marks', status: 'in_progress' }
      ]
    }
  },

  // 100 QUESTION PAPERS INDEX MATRIX (10 Sets for Each Major CBSE Subject)
  questionPaperSets: [
    // CLASS 10 (50 Question Papers)
    { id: 'QP-10-SC-01', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Full Syllabus Paper 1', type: 'Full Mock (MCQ + Written)', marks: 80, time: '3 Hours' },
    { id: 'QP-10-SC-02', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Full Syllabus Paper 2', type: 'Full Mock (MCQ + Written)', marks: 80, time: '3 Hours' },
    { id: 'QP-10-SC-03', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Chemical Reactions & Acids Focus', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-SC-04', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Life Processes & Reproduction', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-SC-05', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Electricity & Magnetic Effects', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-SC-06', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Light: Reflection & Refraction Numericals', type: 'Section Drill', marks: 30, time: '1 Hour' },
    { id: 'QP-10-SC-07', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Case Study & Assertion-Reasoning Drill', type: 'High Yield Drill', marks: 35, time: '1 Hour' },
    { id: 'QP-10-SC-08', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Top 20 Most Repeated PYQs Paper', type: 'PYQ Drill', marks: 50, time: '2 Hours' },
    { id: 'QP-10-SC-09', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Pre-Board Model Exam Paper A', type: 'Pre-Board Simulation', marks: 80, time: '3 Hours' },
    { id: 'QP-10-SC-10', class: 'class10', subject: 'Science', name: 'CBSE 10th Science Pre-Board Model Exam Paper B', type: 'Pre-Board Simulation', marks: 80, time: '3 Hours' },

    { id: 'QP-10-MT-01', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Standard Math Full Mock Paper 1', type: 'Full Mock (Standard)', marks: 80, time: '3 Hours' },
    { id: 'QP-10-MT-02', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Basic Math Full Mock Paper 1', type: 'Full Mock (Basic)', marks: 80, time: '3 Hours' },
    { id: 'QP-10-MT-03', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Math Trigonometry & Heights and Distances', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-MT-04', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Math Quadratic Equations & AP Drill', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-MT-05', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Math Coordinate Geometry & Triangles Proofs', type: 'Section Drill', marks: 35, time: '1 Hour' },
    { id: 'QP-10-MT-06', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Math Surface Areas & Volumes Board Problems', type: 'Numerical Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-MT-07', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Math Statistics & Probability Mastery Set', type: 'High Yield Drill', marks: 30, time: '1 Hour' },
    { id: 'QP-10-MT-08', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Math 10-Year Repeated Theorems & Proofs', type: 'PYQ Drill', marks: 50, time: '2 Hours' },
    { id: 'QP-10-MT-09', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Standard Math Pre-Board Sample Paper', type: 'Pre-Board Simulation', marks: 80, time: '3 Hours' },
    { id: 'QP-10-MT-10', class: 'class10', subject: 'Mathematics', name: 'CBSE 10th Basic Math Pre-Board Sample Paper', type: 'Pre-Board Simulation', marks: 80, time: '3 Hours' },

    { id: 'QP-10-SST-01', class: 'class10', subject: 'Social Science', name: 'CBSE 10th SST Complete Board Model Paper 1', type: 'Full Mock', marks: 80, time: '3 Hours' },
    { id: 'QP-10-SST-02', class: 'class10', subject: 'Social Science', name: 'CBSE 10th SST History & Nationalism Drill', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-SST-03', class: 'class10', subject: 'Social Science', name: 'CBSE 10th SST Political Science: Power Sharing & Federalism', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-SST-04', class: 'class10', subject: 'Social Science', name: 'CBSE 10th SST Economics: Money, Credit & Globalisation', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-10-SST-05', class: 'class10', subject: 'Social Science', name: 'CBSE 10th SST Official Map Work & Locational Points Set', type: 'Map Skill Drill', marks: 20, time: '45 Mins' },
    { id: 'QP-10-SST-06', class: 'class10', subject: 'Social Science', name: 'CBSE 10th SST Long 5-Mark Analytical Question Bank', type: 'Subjective Drill', marks: 50, time: '2 Hours' },
    { id: 'QP-10-SST-07', class: 'class10', subject: 'Social Science', name: 'CBSE 10th SST Pre-Board Comprehensive Exam', type: 'Pre-Board Simulation', marks: 80, time: '3 Hours' },

    { id: 'QP-10-ENG-01', class: 'class10', subject: 'English Language & Lit', name: 'CBSE 10th English Reading, Writing & Grammar Mock 1', type: 'Full Mock', marks: 80, time: '3 Hours' },
    { id: 'QP-10-ENG-02', class: 'class10', subject: 'English Language & Lit', name: 'CBSE 10th English Analytical Paragraph & Formal Letter Writing', type: 'Writing Drill', marks: 30, time: '1 Hour' },
    { id: 'QP-10-ENG-03', class: 'class10', subject: 'English Language & Lit', name: 'CBSE 10th English First Flight & Footprints Literature Test', type: 'Subjective Test', marks: 40, time: '1.5 Hours' },

    { id: 'QP-10-CA-01', class: 'class10', subject: 'Computer Applications', name: 'CBSE 10th Comp App Networking & Cyber Ethics Test', type: 'Theory Test', marks: 30, time: '1 Hour' },
    { id: 'QP-10-CA-02', class: 'class10', subject: 'Computer Applications', name: 'CBSE 10th Comp App HTML & CSS Coding Test Paper', type: 'Practical & Theory', marks: 50, time: '2 Hours' },

    // CLASS 12 (50+ Question Papers across Science, Commerce, Humanities)
    { id: 'QP-12-PHY-01', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Full Syllabus Board Paper 1', type: 'Full Board Mock', marks: 70, time: '3 Hours' },
    { id: 'QP-12-PHY-02', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Full Syllabus Board Paper 2', type: 'Full Board Mock', marks: 70, time: '3 Hours' },
    { id: 'QP-12-PHY-03', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Electrostatics & Current Electricity', type: 'Unit Test', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-PHY-04', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Magnetism, EMI & AC Circuits', type: 'Unit Test', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-PHY-05', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Ray & Wave Optics Derivations Set', type: 'Derivation Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-PHY-06', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Modern Physics (Dual Nature, Atoms, Nuclei)', type: 'Unit Test', marks: 30, time: '1 Hour' },
    { id: 'QP-12-PHY-07', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Semiconductor Electronics & Logic Gates', type: 'Section Drill', marks: 25, time: '45 Mins' },
    { id: 'QP-12-PHY-08', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Case-Study & Assertion-Reasoning Drill', type: 'High Yield Drill', marks: 35, time: '1 Hour' },
    { id: 'QP-12-PHY-09', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Top 15 Mandatory Board Derivations', type: 'Subjective Drill', marks: 50, time: '2 Hours' },
    { id: 'QP-12-PHY-10', class: 'class12', subject: 'Physics', name: 'CBSE 12th Physics Pre-Board Comprehensive Simulation', type: 'Pre-Board Simulation', marks: 70, time: '3 Hours' },

    { id: 'QP-12-CH-01', class: 'class12', subject: 'Chemistry', name: 'CBSE 12th Chemistry Full Syllabus Board Paper 1', type: 'Full Board Mock', marks: 70, time: '3 Hours' },
    { id: 'QP-12-CH-02', class: 'class12', subject: 'Chemistry', name: 'CBSE 12th Chemistry Physical Chemistry (Solutions, Electro, Kinetics)', type: 'Numerical Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-CH-03', class: 'class12', subject: 'Chemistry', name: 'CBSE 12th Chemistry Organic Reactions & Conversions Roadmap', type: 'Reaction Drill', marks: 45, time: '2 Hours' },
    { id: 'QP-12-CH-04', class: 'class12', subject: 'Chemistry', name: 'CBSE 12th Chemistry Coordination Compounds & d-Block', type: 'Inorganic Drill', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-CH-05', class: 'class12', subject: 'Chemistry', name: 'CBSE 12th Chemistry Aldehydes, Ketones & Carboxylic Acids', type: 'Organic Focus', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-CH-06', class: 'class12', subject: 'Chemistry', name: 'CBSE 12th Chemistry Pre-Board Model Exam Paper', type: 'Pre-Board Simulation', marks: 70, time: '3 Hours' },

    { id: 'QP-12-MT-01', class: 'class12', subject: 'Mathematics', name: 'CBSE 12th Math Calculus Marathon Paper (Diff & Integrals)', type: 'Section Drill', marks: 45, time: '2 Hours' },
    { id: 'QP-12-MT-02', class: 'class12', subject: 'Mathematics', name: 'CBSE 12th Math Vectors & 3D Geometry 14-Mark Master Set', type: 'Unit Test', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-MT-03', class: 'class12', subject: 'Mathematics', name: 'CBSE 12th Math Matrices, Determinants & LPP Drill', type: 'Unit Test', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-MT-04', class: 'class12', subject: 'Mathematics', name: 'CBSE 12th Math Full Syllabus Board Simulation Paper 1', type: 'Full Board Mock', marks: 80, time: '3 Hours' },

    { id: 'QP-12-BIO-01', class: 'class12', subject: 'Biology', name: 'CBSE 12th Biology Full Syllabus Mock Paper', type: 'Full Board Mock', marks: 70, time: '3 Hours' },
    { id: 'QP-12-BIO-02', class: 'class12', subject: 'Biology', name: 'CBSE 12th Biology Genetics & Molecular Basis of Inheritance', type: 'High Yield Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-BIO-03', class: 'class12', subject: 'Biology', name: 'CBSE 12th Biology Biotechnology Principles & Processes', type: 'Unit Test', marks: 35, time: '1.5 Hours' },

    { id: 'QP-12-CS-01', class: 'class12', subject: 'Computer Science (Python)', name: 'CBSE 12th CS Python File Handling & Stacks Paper', type: 'Programming Drill', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-CS-02', class: 'class12', subject: 'Computer Science (Python)', name: 'CBSE 12th CS SQL Joins & Networks Theory Paper', type: 'SQL Drill', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-CS-03', class: 'class12', subject: 'Computer Science (Python)', name: 'CBSE 12th CS Full Board Mock Examination', type: 'Full Board Mock', marks: 70, time: '3 Hours' },

    { id: 'QP-12-ACC-01', class: 'class12', subject: 'Accountancy', name: 'CBSE 12th Accountancy Partnership Admission & Retirement', type: 'Numerical Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-ACC-02', class: 'class12', subject: 'Accountancy', name: 'CBSE 12th Accountancy Share Capital & Debentures Pro-Rata', type: 'High Yield Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-ACC-03', class: 'class12', subject: 'Accountancy', name: 'CBSE 12th Accountancy Cash Flow Statement & Ratios Set', type: 'Analysis Drill', marks: 35, time: '1.5 Hours' },
    { id: 'QP-12-ACC-04', class: 'class12', subject: 'Accountancy', name: 'CBSE 12th Accountancy Full Syllabus Board Mock Paper', type: 'Full Board Mock', marks: 80, time: '3 Hours' },

    { id: 'QP-12-BST-01', class: 'class12', subject: 'Business Studies', name: 'CBSE 12th BST Principles & Functions of Management', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-BST-02', class: 'class12', subject: 'Business Studies', name: 'CBSE 12th BST Financial Management & Marketing Case Studies', type: 'Case Study Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-BST-03', class: 'class12', subject: 'Business Studies', name: 'CBSE 12th BST Full Syllabus Board Examination', type: 'Full Board Mock', marks: 80, time: '3 Hours' },

    { id: 'QP-12-ECO-01', class: 'class12', subject: 'Economics', name: 'CBSE 12th Macroeconomics National Income & Multiplier', type: 'Numerical & Theory', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-ECO-02', class: 'class12', subject: 'Economics', name: 'CBSE 12th Indian Economic Development Comprehensive Drill', type: 'Theory Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-ECO-03', class: 'class12', subject: 'Economics', name: 'CBSE 12th Economics Full Board Mock Paper', type: 'Full Board Mock', marks: 80, time: '3 Hours' },

    { id: 'QP-12-HIS-01', class: 'class12', subject: 'History', name: 'CBSE 12th History Harappan & Vijayanagara Ancient Civilisations', type: 'Source & Subjective', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-HIS-02', class: 'class12', subject: 'History', name: 'CBSE 12th History Mahatma Gandhi & Constitution Making', type: 'Essay Drill', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-HIS-03', class: 'class12', subject: 'History', name: 'CBSE 12th History Full Board Mock Examination', type: 'Full Board Mock', marks: 80, time: '3 Hours' },

    { id: 'QP-12-POL-01', class: 'class12', subject: 'Political Science', name: 'CBSE 12th Pol Sci Cold War, Bipolarity & Global Organisations', type: 'Unit Test', marks: 40, time: '1.5 Hours' },
    { id: 'QP-12-POL-02', class: 'class12', subject: 'Political Science', name: 'CBSE 12th Pol Sci Politics in India Since Independence Full Mock', type: 'Full Board Mock', marks: 80, time: '3 Hours' }
  ],

  // RICH CBSE PYQ ARCHIVE FROM 2016 TO 2026
  pyqVault: [
    {
      id: 'pyq-cbse-12-phy-2026',
      board: 'cbse',
      class: 'class12',
      subject: 'Physics',
      stream: 'science_pcm',
      year: '2026',
      title: 'CBSE Class 12 Physics Official Specimen & Pre-Board Paper (2026 Pattern)',
      downloadUrl: '#',
      fileSize: '3.8 MB',
      highlights: 'Competency-based 50% ratio, Ray Optics prism derivations, AC resonance numericals with official CBSE marking scheme.'
    },
    {
      id: 'pyq-cbse-10-sci-2026',
      board: 'cbse',
      class: 'class10',
      subject: 'Science',
      stream: 'general',
      year: '2026',
      title: 'CBSE Class 10 Science Official Board Model Paper (2026 Pattern)',
      downloadUrl: '#',
      fileSize: '3.2 MB',
      highlights: 'New case-study questions, redox balancing, magnetic solenoid rules with stepwise answer rubrics.'
    },
    {
      id: 'pyq-cbse-12-chem-2025',
      board: 'cbse',
      class: 'class12',
      subject: 'Chemistry',
      stream: 'science_pcm',
      year: '2025',
      title: 'CBSE Class 12 Chemistry Board Examination Paper (All India Set 1, 2, 3)',
      downloadUrl: '#',
      fileSize: '4.2 MB',
      highlights: 'Nernst equation calculations, Aldol/Cannizzaro named reaction mechanisms, crystal field splitting energy.'
    },
    {
      id: 'pyq-cbse-10-math-2025',
      board: 'cbse',
      class: 'class10',
      subject: 'Mathematics',
      stream: 'general',
      year: '2025',
      title: 'CBSE Class 10 Standard & Basic Mathematics Board Paper',
      downloadUrl: '#',
      fileSize: '3.1 MB',
      highlights: 'Arithmetic Progressions real-world case studies, circle tangent proofs with full step marks.'
    },
    {
      id: 'pyq-cbse-12-acc-2024',
      board: 'cbse',
      class: 'class12',
      subject: 'Accountancy',
      stream: 'commerce',
      year: '2024',
      title: 'CBSE Class 12 Accountancy Official Board Paper & Balance Sheet',
      downloadUrl: '#',
      fileSize: '3.5 MB',
      highlights: 'Forfeiture & reissue of pro-rata shares, Cash Flow Statement from operating activities.'
    },
    {
      id: 'pyq-cbse-12-cs-2024',
      board: 'cbse',
      class: 'class12',
      subject: 'Computer Science (Python)',
      stream: 'science_pcm',
      year: '2024',
      title: 'CBSE Class 12 Computer Science (Python/SQL) Board Paper',
      downloadUrl: '#',
      fileSize: '2.9 MB',
      highlights: 'Binary file pickling, CSV reader/writer, SQL group by and joins questions with official code.'
    },
    {
      id: 'pyq-cbse-12-pol-2023',
      board: 'cbse',
      class: 'class12',
      subject: 'Political Science',
      stream: 'humanities',
      year: '2023',
      title: 'CBSE Class 12 Political Science Board Question Paper',
      downloadUrl: '#',
      fileSize: '2.8 MB',
      highlights: 'Contemporary world politics, cartoon analysis and partition challenges long answers.'
    },
    {
      id: 'pyq-cbse-10-sst-2022',
      board: 'cbse',
      class: 'class10',
      subject: 'Social Science',
      stream: 'general',
      year: '2022',
      title: 'CBSE Class 10 Social Science Term 2 Board Paper',
      downloadUrl: '#',
      fileSize: '2.7 MB',
      highlights: 'Nationalism in India, manufacturing industries, political parties, map skills solutions.'
    },
    {
      id: 'pyq-cbse-12-math-2021',
      board: 'cbse',
      class: 'class12',
      subject: 'Mathematics',
      stream: 'science_pcm',
      year: '2021',
      title: 'CBSE Class 12 Mathematics Term 1 & 2 Special Board Papers',
      downloadUrl: '#',
      fileSize: '3.6 MB',
      highlights: 'Matrices, linear programming, integrals and 3D geometry question analysis.'
    },
    {
      id: 'pyq-cbse-12-phy-2020',
      board: 'cbse',
      class: 'class12',
      subject: 'Physics',
      stream: 'science_pcm',
      year: '2020',
      title: 'CBSE Class 12 Physics Pre-Pandemic Regular Board Paper (55/1/1)',
      downloadUrl: '#',
      fileSize: '4.0 MB',
      highlights: 'Gauss Law derivations, moving coil galvanometer sensitivity, Young\'s double slit.'
    },
    {
      id: 'pyq-cbse-10-sci-2019',
      board: 'cbse',
      class: 'class10',
      subject: 'Science',
      stream: 'general',
      year: '2019',
      title: 'CBSE Class 10 Science All India Board Paper',
      downloadUrl: '#',
      fileSize: '3.0 MB',
      highlights: 'Carbon compounds isomerism, female reproductive system, Ohm\'s law verification.'
    },
    {
      id: 'pyq-cbse-12-chem-2018',
      board: 'cbse',
      class: 'class12',
      subject: 'Chemistry',
      stream: 'science_pcm',
      year: '2018',
      title: 'CBSE Class 12 Chemistry Board Paper',
      downloadUrl: '#',
      fileSize: '3.4 MB',
      highlights: 'Coordination IUPAC naming, Raoult\'s law deviations, chemical kinetics rate equations.'
    },
    {
      id: 'pyq-cbse-10-math-2017',
      board: 'cbse',
      class: 'class10',
      subject: 'Mathematics',
      stream: 'general',
      year: '2017',
      title: 'CBSE Class 10 Mathematics All India Examination',
      downloadUrl: '#',
      fileSize: '2.8 MB',
      highlights: 'Heights and distances 60°/30° angles, arithmetic progression sum proofs.'
    },
    {
      id: 'pyq-cbse-12-phy-2016',
      board: 'cbse',
      class: 'class12',
      subject: 'Physics',
      stream: 'science_pcm',
      year: '2016',
      title: 'CBSE Class 12 Physics All India Board Examination Paper',
      downloadUrl: '#',
      fileSize: '3.9 MB',
      highlights: 'Cyclotron principle, transformer step-up/down power losses, astronomical telescope.'
    }
  ],

  // CORE HIGH-YIELD QUESTIONS FOR MOCK QUIZZES
  questions: [
    {
      id: 101,
      class: 'class10',
      subject: 'Science',
      stream: 'general',
      type: 'pyq',
      yearBadge: 'CBSE 2024 / 2020 Repeated',
      difficulty: 'Medium',
      question: 'Which of the following reaction represents a thermal decomposition reaction in CBSE syllabus?',
      options: [
        '2H2 + O2 → 2H2O',
        '2FeSO4 (s) —[Heat]→ Fe2O3 (s) + SO2 (g) + SO3 (g)',
        'Zn + CuSO4 → ZnSO4 + Cu',
        'NaOH + HCl → NaCl + H2O'
      ],
      answer: 1,
      explanation: 'Ferrous sulphate crystals break down upon heating into ferric oxide, sulphur dioxide, and sulphur trioxide with a distinct burning sulphur smell.'
    },
    {
      id: 102,
      class: 'class10',
      subject: 'Science',
      stream: 'general',
      type: 'expected',
      yearBadge: 'Predicted 2026/2027 CBSE Board Question',
      difficulty: 'Hard',
      question: 'A convex lens forms a real, inverted and same sized image of an object. If focal length is 15 cm, where is the object placed and what is the magnification?',
      options: [
        'Object at 15 cm, Magnification = +1',
        'Object at 30 cm, Magnification = -1',
        'Object at 30 cm, Magnification = +1',
        'Object at 45 cm, Magnification = -0.5'
      ],
      answer: 1,
      explanation: 'When placed at 2F (2 × 15 = 30 cm), image is formed at 2F inverted and equal in size. Magnification m = -1.'
    },
    {
      id: 103,
      class: 'class10',
      subject: 'Mathematics',
      stream: 'general',
      type: 'pyq',
      yearBadge: 'CBSE 2024 Standard Math Set 1',
      difficulty: 'Medium',
      question: 'If the HCF of 65 and 117 is expressible in the form 65m - 117, find the value of m:',
      options: ['4', '2', '1', '3'],
      answer: 1,
      explanation: 'HCF(65, 117) = 13. Given 65m - 117 = 13 => 65m = 130 => m = 2.'
    },
    {
      id: 104,
      class: 'class10',
      subject: 'Social Science',
      stream: 'general',
      type: 'pyq',
      yearBadge: 'CBSE 2023 Board Exam',
      difficulty: 'Easy',
      question: 'The Poona Pact of September 1932 was signed between Mahatma Gandhi and:',
      options: ['Lord Irwin', 'Dr. B.R. Ambedkar', 'Muhammad Ali Jinnah', 'Subhash Chandra Bose'],
      answer: 1,
      explanation: 'Signed between Gandhi and Dr. B.R. Ambedkar, reserving seats for Depressed Classes within the general electorate.'
    },
    {
      id: 201,
      class: 'class12',
      subject: 'Physics',
      stream: 'science_pcm',
      type: 'pyq',
      yearBadge: 'CBSE 2024 Board Set 55/1/1',
      difficulty: 'Hard',
      question: 'An electric dipole of moment p is kept in uniform electric field E. The torque and potential energy when anti-parallel to field (θ = 180°) are:',
      options: [
        'τ = 0, U = +pE (Unstable equilibrium)',
        'τ = pE, U = 0',
        'τ = 0, U = -pE (Stable equilibrium)',
        'τ = pE sin 90°, U = -pE'
      ],
      answer: 0,
      explanation: 'τ = pE sin(180°) = 0. U = -pE cos(180°) = +pE (maximum potential energy = unstable equilibrium).'
    },
    {
      id: 202,
      class: 'class12',
      subject: 'Physics',
      stream: 'science_pcm',
      type: 'expected',
      yearBadge: 'High-Yield Predicted 2026/2027',
      difficulty: 'Medium',
      question: 'In Young\'s Double Slit Experiment, if slit spacing d is halved and screen distance D is doubled, the fringe width β becomes:',
      options: ['Halved', 'Unchanged', 'Quadrupled (4 times)', 'Doubled'],
      answer: 2,
      explanation: 'β = λD/d. Doubling D and halving d gives β\' = λ(2D)/(d/2) = 4(λD/d) = 4β.'
    },
    {
      id: 203,
      class: 'class12',
      subject: 'Chemistry',
      stream: 'science_pcm',
      type: 'pyq',
      yearBadge: 'CBSE 2024 All India',
      difficulty: 'Medium',
      question: 'Which of the following 0.1 M solutions has the highest boiling point elevation?',
      options: ['0.1 M Glucose (i=1)', '0.1 M NaCl (i=2)', '0.1 M BaCl2 (i=3)', '0.1 M Al2(SO4)3 (i=5)'],
      answer: 3,
      explanation: 'ΔTb = i × Kb × m. Al2(SO4)3 dissociates into 5 ions, having the highest van\'t Hoff factor i = 5.'
    },
    {
      id: 204,
      class: 'class12',
      subject: 'Computer Science (Python)',
      stream: 'science_pcm',
      type: 'pyq',
      yearBadge: 'CBSE 2024 Class 12 CS Paper',
      difficulty: 'Medium',
      question: 'In MySQL, which clause is strictly required to filter aggregate groups formed by GROUP BY?',
      options: ['WHERE', 'HAVING', 'ORDER BY', 'LIMIT'],
      answer: 1,
      explanation: 'HAVING filters aggregate conditions (e.g. HAVING COUNT(*) > 5); WHERE cannot filter aggregate functions.'
    },
    {
      id: 301,
      class: 'class12',
      subject: 'Accountancy',
      stream: 'commerce',
      type: 'pyq',
      yearBadge: 'CBSE 2024 Board Paper',
      difficulty: 'Medium',
      question: 'In the absence of a Partnership Deed, interest on partner\'s loan is allowed at:',
      options: ['No interest', '6% per annum simple interest', '10% per annum', '12% per annum'],
      answer: 1,
      explanation: 'As per Indian Partnership Act 1932 Section 13(d), partners are entitled to 6% p.a. interest on loans made to the firm.'
    },
    {
      id: 401,
      class: 'class12',
      subject: 'History',
      stream: 'humanities',
      type: 'pyq',
      yearBadge: 'CBSE 2024 Board Paper',
      difficulty: 'Easy',
      question: 'The "Great Bath" was discovered in which of the following Harappan sites?',
      options: ['Harappa', 'Kalibangan', 'Mohenjodaro', 'Lothal'],
      answer: 2,
      explanation: 'The Great Bath was discovered at Mohenjodaro and was used for special ritual bathing.'
    }
  ],

  // SUBJECTIVE QUESTIONS FOR WRITTEN EVALUATION
  subjectiveQuestions: [
    {
      id: 'sub1',
      class: 'class10',
      subject: 'Science',
      stream: 'general',
      question: 'Explain the mechanism of transport of water and minerals in plants through xylem. What is the role of transpiration pull? (3 Marks)',
      maxMarks: 3,
      keywords: ['xylem vessels', 'tracheids', 'root pressure', 'transpiration pull', 'continuous water column', 'stomata', 'cohesion'],
      rubric: [
        { criterion: 'Mentioning xylem vessels & root absorption', marks: 1 },
        { criterion: 'Explaining evaporation creating suction (transpiration pull)', marks: 1 },
        { criterion: 'Formation of continuous water column & upward movement', marks: 1 }
      ],
      modelAnswer: 'Water and soluble minerals are absorbed by root hairs from soil through active ion uptake. In leaves, water evaporates through stomatal apertures during transpiration, creating a suction force called the transpiration pull. This draws water upward through continuous xylem vessels from roots to foliage.'
    },
    {
      id: 'sub2',
      class: 'class12',
      subject: 'Physics',
      stream: 'science_pcm',
      question: 'State Lenz\'s law of electromagnetic induction. Show that it is in accordance with the law of conservation of energy. (3 Marks)',
      maxMarks: 3,
      keywords: ['direction of induced current', 'opposes the cause', 'conservation of energy', 'mechanical work', 'magnetic flux', 'induced emf'],
      rubric: [
        { criterion: 'Formal statement of Lenz\'s law', marks: 1 },
        { criterion: 'Work done against repulsive/attractive magnetic forces', marks: 1 },
        { criterion: 'Mechanical work converted into electrical/thermal energy', marks: 1 }
      ],
      modelAnswer: 'Lenz\'s law states that the polarity of induced emf and direction of induced current opposes the change in magnetic flux producing it. When a magnet approaches a coil, repulsive forces oppose its motion. Mechanical work done against this repulsion is converted into electrical energy, satisfying conservation of energy.'
    },
    {
      id: 'sub3',
      class: 'class12',
      subject: 'Chemistry',
      stream: 'science_pcm',
      question: 'Differentiate between order and molecularity of a chemical reaction with at least three key distinctions. (3 Marks)',
      maxMarks: 3,
      keywords: ['experimental', 'theoretical', 'zero or fractional', 'integer only', 'elementary reaction', 'rate law'],
      rubric: [
        { criterion: 'Order is experimental vs Molecularity is theoretical', marks: 1 },
        { criterion: 'Order can be zero/fractional vs Molecularity is whole integer', marks: 1 },
        { criterion: 'Order applies to complex reactions vs Molecularity only to elementary', marks: 1 }
      ],
      modelAnswer: '1. Order is experimentally determined from rate law; Molecularity is a theoretical mechanism concept.\n2. Order can be 0, fractional, or negative; Molecularity is always positive whole integer (1, 2, 3).\n3. Order applies to complex and elementary reactions; Molecularity has meaning only for single-step elementary reactions.'
    },
    {
      id: 'sub4',
      class: 'class12',
      subject: 'Accountancy',
      stream: 'commerce',
      question: 'Explain the concept of "Working Capital" and mention two factors that influence working capital requirements. (3 Marks)',
      maxMarks: 3,
      keywords: ['current assets', 'current liabilities', 'operating cycle', 'scale of operations', 'nature of business'],
      rubric: [
        { criterion: 'Definition of Working Capital (Current Assets - Current Liabilities)', marks: 1 },
        { criterion: 'Factor 1: Nature of business / Length of Operating cycle', marks: 1 },
        { criterion: 'Factor 2: Scale of operations or credit policy', marks: 1 }
      ],
      modelAnswer: 'Working Capital represents Current Assets minus Current Liabilities (Net Working Capital), required for day-to-day operations. Two key factors are: (1) Nature of Business: Manufacturing firms need larger working capital than trading/service firms. (2) Length of Operating Cycle: Longer inventory and collection cycles increase working capital demand.'
    }
  ],

  // ALL INDIA LIVE LEADERBOARD
  leaderboard: [
    { rank: 1, name: "Aarav Sharma", school: "DPS R.K. Puram, Delhi", score: "99.4%", hours: "54 hrs", stream: "CBSE 12th Science", badge: "🥇 AIR 1" },
    { rank: 2, name: "Ananya Iyer", school: "National Public School, Bengaluru", score: "98.8%", hours: "51 hrs", stream: "CBSE 12th Commerce", badge: "🥈 AIR 2" },
    { rank: 3, name: "Aditya Verma", school: "St. Xavier's High School, Mumbai", score: "98.2%", hours: "49 hrs", stream: "CBSE 12th PCB", badge: "🥉 AIR 3" },
    { rank: 4, name: "Pooja Reddy", school: "Hyderabad Public School, Begumpet", score: "97.6%", hours: "46 hrs", stream: "CBSE 12th Humanities", badge: "⭐ Top 10" },
    { rank: 5, name: "Tanmay Bansal", school: "DAV Public School, Chandigarh", score: "96.9%", hours: "43 hrs", stream: "CBSE 10th Standard", badge: "⭐ Top 10" },
    { rank: 6, name: "You (Current Standing)", school: "CBSE Student", score: "89.0%", hours: "38 hrs", stream: "CBSE Board", badge: "🌟 On Track" }
  ],

  quotes: [
    { text: "Your CBSE board exam score is a measure of your preparation for this specific test, not a measure of your worth or destiny.", author: "CBSE Academic Counselor" },
    { text: "One formula at a time, one derivation at a time. Consistency beats intensity every single time.", author: "Board Topper Mantra" },
    { text: "When panic kicks in, take 3 deep belly breaths. Your brain simply needs oxygen to recall what you already studied.", author: "Exam Psychologist" },
    { text: "Rest is not a waste of time; deep sleep is when your brain locks concepts into permanent memory.", author: "Neuroscience of Learning" }
  ]
};
